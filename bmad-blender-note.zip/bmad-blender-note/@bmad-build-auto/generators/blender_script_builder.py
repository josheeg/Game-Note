"""
Blender Script Builder Module
==============================
Ingests context from @bmad-project-context and builds executable Blender Python scripts.
"""

import json
from pathlib import Path


class BlenderScriptBuilder:
    """Ingests context from @bmad-project-context and builds executable Blender scripts."""
    
    def __init__(self, context_path: Path, config: dict = None):
        self.context_path = context_path
        with open(context_path, 'r', encoding='utf-8') as f:
            self.spec = json.load(f)
        
        self.config = config or {
            "target_engine": "CYCLES",
            "use_nodes": True,
            "background_color": [0.05, 0.05, 0.08]
        }
    
    def generate_code(self) -> str:
        """Generate Blender Python script from context."""
        
        scene_cfg = self.spec.get("scene", {})
        objects = self.spec.get("objects", [])
        project_name = self.spec.get("project_name", "BMAD Auto-Generated Scene")
        target_engine = self.config.get("target_engine", "CYCLES")
        resolution_x = int(scene_cfg.get("resolution", [1920, 1080])[0])
        resolution_y = int(scene_cfg.get("resolution", [1920, 1080])[1])
        bg_color = self.config.get("background_color", [0.05, 0.05, 0.08])
        
        if len(bg_color) == 3:
            bg_color = bg_color + [1.0]
        
        # Build script header
        code = [
            f"# Auto-generated Blender Python Script by BMAD AI Build Automation",
            f"# Source Context: {project_name}",
            f"# Version: {self.spec.get('version', '1.0')}",
            "",
            "import bpy",
            "from mathutils import Vector, Euler",
            "",
            "# ==============================================",
            "# 1. RESET SCENE",
            "# ==============================================",
            "bpy.ops.wm.read_factory_settings(use_empty=True)",
            "",
            "# ==============================================",
            "# 2. CONFIGURE RENDER ENGINE",
            "# ==============================================",
            f'bpy.context.scene.render.engine = "{target_engine}"',
            f"bpy.context.scene.render.resolution_x = {resolution_x}",
            f"bpy.context.scene.render.resolution_y = {resolution_y}",
            f"bpy.context.scene.view_settings.look = 'Standard'",
            "",
            "# ==============================================",
            "# 3. CREATE OBJECTS",
            "# =============================================="
        ]
        
        for obj in objects:
            name = obj.get("name", "Unnamed_Object")
            obj_type = obj.get("type", "")
            
            # Handle location
            loc = obj.get("location", [0, 0, 0])
            x, y, z = self._parse_location(loc)
            
            code.append(f"# {name}")
            
            # Generate object creation code based on type
            if obj_type == "CUBE":
                size = obj.get("scale", 1)
                code.append(f"bpy.ops.mesh.primitive_cube_add(size={size}, location=({x}, {y}, {z}))")
                bpy_obj_name = self._sanitize_name(name)
                code.append(f"{bpy_obj_name} = bpy.context.active_object")
                
            elif obj_type == "SPHERE":
                radius = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
                segments = obj.get("segments", 32)
                location_str = ", ".join(str(v) for v in loc[:3])
                code.append(f"bpy.ops.mesh.primitive_uv_sphere_add(radius={radius}, location=({location_str}))")
                bpy_obj_name = self._sanitize_name(name)
                code.append(f"{bpy_obj_name} = bpy.context.active_object")
                
            elif obj_type == "CONE":
                radius = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
                location_str = ", ".join(str(v) for v in loc[:3])
                code.append(f"bpy.ops.mesh.primitive_cone_add(radius={radius}, location=({location_str}))")
                bpy_obj_name = self._sanitize_name(name)
                code.append(f"{bpy_obj_name} = bpy.context.active_object")
                
            elif obj_type == "CYLINDER":
                radius = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
                depth = obj.get("scale", 1) * 2 if isinstance(obj.get("scale"), (int, float)) else 2.0
                location_str = ", ".join(str(v) for v in loc[:3])
                code.append(f"bpy.ops.mesh.primitive_cylinder_add(radius={radius}, depth={depth}, location=({location_str}))")
                bpy_obj_name = self._sanitize_name(name)
                code.append(f"{bpy_obj_name} = bpy.context.active_object")
                
            elif obj_type == "TORUS":
                major_radius = obj.get("scale", 1) * 2 if isinstance(obj.get("scale"), (int, float)) else 3.0
                minor_radius = obj.get("scale", 1) / 2 if isinstance(obj.get("scale"), (int, float)) else 1.0
                location_str = ", ".join(str(v) for v in loc[:3])
                code.append(f"bpy.ops.mesh.primitive_torus_add(major_radius={major_radius}, minor_radius={minor_radius}, location=({location_str}))")
                bpy_obj_name = self._sanitize_name(name)
                code.append(f"{bpy_obj_name} = bpy.context.active_object")
            
            # Handle materials if defined
            material_cfg = obj.get("material", {})
            if material_cfg and self.config.get("use_nodes", True):
                mat_name = material_cfg.get("name", f"{name}_Material").replace("'", "_")
                code.append("")
                code.append(f"# Apply material to {bpy_obj_name}")
                code.append(f"mat = bpy.data.materials.new(name='{mat_name}')")
                code.append("mat.use_nodes = True")
                code.append("nodes = mat.node_tree.nodes")
                
                # Get or create BSDF node
                bsdf_node = nodes.get("Principled BSDF", None)
                if not bsdf_node:
                    code.append(f"bsdf_node = nodes.new('ShaderNodeBSDF')")
                    code.append(f"bsdf_node.location = ({-200}, 0)")
                else:
                    code.append(f"bsdf_node = nodes['Principled BSDF']")
                
                bsdf_name = "bsdf_node"
                code.append("")
                code.append(f"# Set Base Color")
                base_color = material_cfg.get("base_color", [1, 1, 1])
                if isinstance(base_color, dict):
                    r, g, b = base_color.get("r", 0), base_color.get("g", 0), base_color.get("b", 0)
                else:
                    r, g, b = base_color[0], base_color[1], base_color[2] if len(base_color) > 2 else 1
                code.append(f"{bsdf_name}.inputs['Base Color'].default_value = ({r}, {g}, {b}, 1.0)")
                
                # Metallic
                metallic = material_cfg.get("metallic", 0.0)
                code.append(f"{bsdf_name}.inputs['Metallic'].default_value = {metallic}")
                
                # Roughness
                roughness = material_cfg.get("roughness", 0.5)
                code.append(f"{bsdf_name}.inputs['Roughness'].default_value = {roughness}")
                
                # Transmission (for glass-like materials)
                transmission = material_cfg.get("transmission", 0.0)
                if transmission > 0:
                    code.append(f"{bsdf_name}.inputs['Transmission'].default_value = {transmission}")
                
                # Emissive handling
                if material_cfg.get("emissive", False):
                    emission_strength = material_cfg.get("emission_strength", 1.0)
                    emissive_node = nodes.get('Emission', None)
                    if not emissive_node:
                        code.append(f"emissive_node = nodes.new('ShaderNodeEmission')")
                        code.append(f"emissive_node.location = ({200}, 0)")
                    else:
                        code.append(f"emissive_node = nodes['Emission']")
                    
                    emissive_str = "emissive_node"
                    if isinstance(material_cfg.get("base_color", [1,1,1]), dict):
                        r_e, g_e, b_e = material_cfg["base_color"]["r"], material_cfg["base_color"]["g"], material_cfg["base_color"]["b"]
                    else:
                        r_e, g_e, b_e = material_cfg["base_color"][0], material_cfg["base_color"][1], 1.0
                    
                    code.append(f"{emissive_str}.inputs['Color'].default_value = ({r_e}, {g_e}, {b_e}, 1.0)")
                    code.append(f"{emissive_str}.inputs['Strength'].default_value = {emission_strength}")
                    
                    # Link emission to BSDF output for additivity (simple approach)
                    output_node = nodes.get("Output", None)
                    if not output_node:
                        code.append(f"output_node = nodes.new('ShaderNodeOutput')")
                        code.append(f"output_node.location = ({0}, -200)")
                    else:
                        code.append(f"output_node = nodes['Output']")
                    
                    code.append(f"links = mat.node_tree.links")
                    code.append(f"links.new({bsdf_name}.outputs['BSDF'], {emissive_str}.inputs['Surface'])")
                    code.append(f"links.new({emissive_str}.outputs['Emission'], output_node.inputs['Surface'])")
                else:
                    # Standard setup
                    output_node = nodes.get("Output", None)
                    if not output_node:
                        code.append(f"output_node = nodes.new('ShaderNodeOutput')")
                        code.append(f"output_node.location = ({0}, -200)")
                    else:
                        code.append(f"output_node = nodes['Output']")
                    
                    code.append(f"links = mat.node_tree.links")
                    code.append(f"links.new({bsdf_name}.outputs['BSDF'], output_node.inputs['Surface'])")
                
                # Add material to object
                code.append(f"{bpy_obj_name}.data.materials.append(mat)")
        
        # ==============================================
        # 4. ENVIRONMENT SETUP
        # ==============================================
        env_cfg = self.spec.get("environment", {})
        if env_cfg:
            fog_enabled = env_cfg.get("fog_enabled", False)
            sun_light = env_cfg.get("sun_light", True)
            ambient_strength = env_cfg.get("ambient_strength", 0.3)
            
            code.append("")
            code.append("# ==============================================")
            code.append("# 5. ENVIRONMENT SETUP")
            code.append("# ==============================================")
            
            if sun_light:
                code.append("")
                code.append("# Add Sun Light")
                code.append("bpy.ops.object.light_add(type='SUN', location=(0, -10, 40))")
                sun_obj = bpy.context.active_object.name.replace(" ", "_").replace("-", "_")
                code.append(f"{sun_obj}.energy = 2.0")
                code.append(f"{sun_obj}.shadow_softness = {env_cfg.get('shadow_softness', 15.0)}")
            
            if ambient_strength > 0:
                code.append("")
                code.append("# Add Ambient Light (Area Light)")
                code.append("bpy.ops.object.light_add(type='AREA', location=(5, -20, 10))")
                area_obj = bpy.context.active_object.name.replace(" ", "_").replace("-", "_")
                code.append(f"{area_obj}.size = {env_cfg.get('area_size', 8.0)}")
                code.append(f"{area_obj}.energy = {ambient_strength}")
            
            # Set background color
            code.append("")
            code.append("# Set background")
            code.append(f"scene.background = ({bg_color[0]}, {bg_color[1]}, {bg_color[2]}, {bg_color[3] if len(bg_color) == 4 else 1.0})")
        
        # ==============================================
        # 6. SELECTION & ACTIVE OBJECT
        # ==============================================
        code.append("")
        code.append("# ==============================================")
        code.append("# 7. FINALIZE: SELECT ACTIVE OBJECT")
        code.append("# ==============================================")
        
        all_objects = bpy.data.objects
        if all_objects:
            last_object = list(all_objects)[-1]
            code.append(f"bpy.context.view_layer.objects.active = {last_object.name.replace(' ', '_').replace('-', '_')}")
        
        # ==============================================
        code.append("")
        code.append("# Script generation complete!")
        code.append("print(\"[BMAD] Scene generation completed successfully.\")")
        
        return "\n".join(code)
    
    def save_script(self, output_path: Path):
        """Generate and save the Blender script."""
        code = self.generate_code()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(code)
    
    @staticmethod
    def _parse_location(loc):
        """Parse and normalize location data."""
        if isinstance(loc, dict):
            x = loc.get("x", 0)
            y = loc.get("y", 0)
            z = loc.get("z", 0)
        elif len(loc) == 1:
            x, y, z = loc[0], 0, 0
        else:
            x, y, z = loc
        
        return float(x), float(y), float(z)
    
    @staticmethod
    def _sanitize_name(name: str) -> str:
        """Sanitize object name for Python variable usage."""
        # Replace spaces, hyphens with underscores
        sanitized = name.replace(" ", "_").replace("-", "_")
        # Limit length to 63 characters (Python identifier limit)
        if len(sanitized) > 63:
            sanitized = sanitized[:63]
        return sanitized
