"""
Context Parser Module
======================
Parses and validates @bmad-project-context files for script generation.
"""

import json
from pathlib import Path


class ContextParser:
    """Parse and validate BMAD project context specifications."""
    
    def __init__(self, context_path: Path):
        self.context_path = context_path
        self.spec = None
    
    def load(self) -> dict:
        """Load and parse context specification file."""
        if not self.context_path.exists():
            raise FileNotFoundError(f"Context file not found: {self.context_path}")
        
        with open(self.context_path, 'r', encoding='utf-8') as f:
            self.spec = json.load(f)
        
        return self.spec
    
    def validate(self) -> bool:
        """Validate the loaded context against schema requirements."""
        if self.spec is None:
            return False
        
        required_keys = ["project_name", "version", "target_engine", "objects"]
        
        for key in required_keys:
            if key not in self.spec:
                print(f"[BMAD Parser] Warning: Missing required field: {key}")
                return False
        
        # Validate objects array
        objects = self.spec.get("objects", [])
        if not isinstance(objects, list):
            print("[BMAD Parser] Error: 'objects' must be an array")
            return False
        
        for obj in objects:
            if "name" not in obj or "type" not in obj:
                print(f"[BMAD Parser] Warning: Object missing 'name' or 'type': {obj}")
        
        return True
    
    def get_scene_config(self) -> dict:
        """Extract scene configuration."""
        return self.spec.get("scene", {})
    
    def get_objects(self) -> list:
        """Get list of objects to generate."""
        return self.spec.get("objects", [])
    
    def get_environment(self) -> dict:
        """Get environment settings."""
        return self.spec.get("environment", {})


class ConfigParser:
    """Parse YAML configuration files (simple parser)."""
    
    @staticmethod
    def parse_yaml_simple(yaml_content: str) -> dict:
        """Simple YAML parser for basic key-value pairs."""
        config = {}
        for line in yaml_content.split('\n'):
            if ':' in line and not line.strip().startswith('#'):
                parts = line.strip().split(':', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    config[key] = value
        return config
    
    @staticmethod
    def load_config(config_path: Path) -> dict:
        """Load and parse config.yaml file."""
        if not config_path.exists():
            # Return defaults
            return {
                "target_engine": "CYCLES",
                "units": "METRIC",
                "resolution": [1920, 1080],
                "samples": 128,
                "use_nodes": True,
                "background_color": [0.05, 0.05, 0.08]
            }
        
        with open(config_path, 'r', encoding='utf-8') as f:
            raw_content = f.read()
        
        # Simple YAML parsing
        config_dict = ConfigParser.parse_yaml_simple(raw_content)
        
        # Merge with defaults for missing keys
        defaults = {
            "target_engine": "CYCLES",
            "units": "METRIC",
            "resolution": [1920, 1080],
            "samples": 128,
            "use_nodes": True,
            "background_color": [0.05, 0.05, 0.08]
        }
        
        for key, value in defaults.items():
            if key not in config_dict:
                config_dict[key] = value
        
        return {k.strip(): v.strip() for k, v in config_dict.items()}
