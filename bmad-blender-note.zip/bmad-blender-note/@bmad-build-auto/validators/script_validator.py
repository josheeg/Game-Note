"""
Script Validator Module
=======================
Pre-execution code & syntax validators for Blender Python scripts.
"""

import ast
import re
from pathlib import Path


class ScriptValidator:
    """Validate generated Blender Python scripts before execution."""
    
    def __init__(self, script_path: Path):
        self.script_path = script_path
        self.errors = []
        self.warnings = []
        self.info = []
    
    def validate(self) -> bool:
        """Run all validation checks and return if script is valid."""
        
        # Check file exists
        if not self.script_path.exists():
            self.errors.append(f"Script file does not exist: {self.script_path}")
            return False
        
        # Read and check file content
        try:
            with open(self.script_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            self._validate_syntax(content)
            self._validate_imports(content)
            self._validate_structure(content)
            self._validate_blender_operations(content)
            
        except SyntaxError as e:
            self.errors.append(f"Syntax error in script: {e}")
            return False
        
        # Report results
        if self.info:
            for msg in self.info:
                print(f"[BMAD Validator] ℹ️  {msg}")
        
        if self.warnings:
            for warning in self.warnings:
                print(f"[BMAD Validator] ⚠️  {warning}")
        
        if self.errors:
            for error in self.errors:
                print(f"[BMAD Validator] ❌ {error}")
            return False
        
        return True
    
    def _validate_syntax(self, content: str):
        """Validate Python syntax."""
        try:
            ast.parse(content)
            self.info.append("✓ Python syntax is valid")
        except SyntaxError as e:
            self.errors.append(f"Invalid Python syntax at line {e.lineno}: {e.msg}")
    
    def _validate_imports(self, content: str):
        """Validate required Blender imports."""
        required_imports = ["import bpy", "from mathutils"]
        
        for imp in required_imports:
            if imp not in content:
                self.errors.append(f"Missing required import: {imp}")
        
        self.info.append("✓ Required imports present")
    
    def _validate_structure(self, content: str):
        """Validate script structure (sections)."""
        sections = ["RESET SCENE", "CONFIGURE RENDER ENGINE", "CREATE OBJECTS"]
        
        for section in sections:
            if f"# {section}" not in content:
                self.warnings.append(f"Missing or misplaced section: {section}")
        
        self.info.append("✓ Script structure validated")
    
    def _validate_blender_operations(self, content: str):
        """Validate Blender-specific operations."""
        # Check for common issues
        
        if "bpy.ops.wm.read_factory_settings" not in content:
            self.warnings.append("Scene is not being reset - factory settings recommended")
        
        if ".engine = " not in content:
            self.warnings.append("Render engine is not explicitly set")
        
        # Check for material node setup
        if "mat.use_nodes = True" not in content and any(".material" in c for c in re.split(r'\n', content)):
            self.warnings.append("Materials may be using legacy shader system")
    
    def get_report(self) -> str:
        """Generate validation report."""
        lines = [
            "=" * 60,
            "BMAD Script Validation Report",
            "=" * 60,
            "",
            f"Script: {self.script_path}",
            f"Status: {'VALID' if not self.errors else 'INVALID'}",
            "",
        ]
        
        if self.info:
            lines.append("Information:")
            for msg in self.info:
                lines.append(f"  • {msg}")
            lines.append("")
        
        if self.warnings:
            lines.append("Warnings:")
            for w in self.warnings:
                lines.append(f"  • {w}")
            lines.append("")
        
        if self.errors:
            lines.append("Errors:")
            for e in self.errors:
                lines.append(f"  • {e}")
            lines.append("")
        
        lines.append("=" * 60)
        return "\n".join(lines)


def quick_validate(script_path: Path) -> dict:
    """Quick validation returning structured results."""
    validator = ScriptValidator(script_path)
    is_valid = validator.validate()
    
    return {
        "path": str(script_path),
        "is_valid": is_valid,
        "errors": validator.errors,
        "warnings": validator.warnings,
        "info": validator.info
    }
