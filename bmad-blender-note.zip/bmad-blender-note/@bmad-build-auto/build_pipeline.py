#!/usr/bin/env python3
"""
BMAD Auto Build Pipeline
========================
Main CLI entry point for Blender script generation.
Reads context from @bmad-project-context and outputs executable Blender Python scripts.

Usage:
    python build_pipeline.py [options]

Options:
    --context PATH   Path to context spec file (default: ./@bmad-project-context/specs/scene_config.json)
    --output PATH    Output directory for generated scripts (default: ./build_output/generated_scripts)
"""

import argparse
import json
from pathlib import Path


def parse_context(context_path: Path) -> dict:
    """Parse and validate context specification file."""
    if not context_path.exists():
        raise FileNotFoundError(f"Context file not found: {context_path}")
    
    with open(context_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_config(yaml_path: Path) -> dict:
    """Load global configuration from config.yaml."""
    default_config = {
        "target_engine": "CYCLES",
        "units": "METRIC",
        "resolution": [1920, 1080],
        "samples": 128,
        "use_nodes": True,
        "background_color": [0.05, 0.05, 0.08]
    }
    
    try:
        with open(yaml_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        config_dict = {}
        for line in content.split('\n'):
            if ':' in line and not line.strip().startswith('#'):
                parts = line.strip().split(':', 1)
                if len(parts) == 2:
                    key = parts[0].strip()
                    value = parts[1].strip()
                    
                    # Handle list values like [0.05, 0.05, 0.08]
                    if value.startswith('[') and value.endswith(']'):
                        list_str = value[1:-1].strip()
                        items = []
                        for item in list_str.split(','):
                            item = item.strip()
                            if '.' in item:
                                items.append(float(item))
                            else:
                                try:
                                    items.append(int(item))
                                except:
                                    items.append(item)
                        value = items
                    
                    config_dict[key] = value
        
        # Merge with defaults
        for key, default_value in default_config.items():
            if key not in config_dict or (isinstance(default_value, list) and isinstance(config_dict.get(key), str)):
                config_dict[key] = default_value
        
        return {k.strip(): v.strip() if isinstance(v, str) else v for k, v in config_dict.items()}
    except Exception as e:
        print(f"[BMAD BUILD] Warning: Could not parse YAML config: {e}")
        return default_config


def generate_blender_script(context_path: Path, config: dict = None) -> str:
    """Generate Blender Python script from context specification."""
    
    with open(context_path, 'r', encoding='utf-8') as f:
        spec = json.load(f)
    
    if config is None:
        yaml_config = load_config(Path('@bmad-project-context/config.yaml'))
        config = yaml_config
    
    scene_cfg = spec.get("scene", {})
    objects = spec.get("objects", [])
    project_name = spec.get("project_name", "BMAD Auto-Generated Scene")
    target_engine = config.get("target_engine", "CYCLES")
    resolution_x = int(scene_cfg.get("resolution", [1920, 1080])[0])
    resolution_y = int(scene_cfg.get("resolution", [1920, 1080])[1])
    
    # Build script header
    code = [
        f"# Auto-generated Blender Python Script by BMAD AI Build Automation",
        f"# Source Context: {project_name}",
        f"# Version: {spec.get('version', '1.0')}",
        "",
        "import bpy",
        "",
        "# ==============================================",
        "# 1. RESET SCENE",
        "# ==============================================",
        "bpy.ops.wm.read_factory_settings(use_empty=True)",
        "",
        "# ==============================================",
        "# 2. CONFIGURE RENDER ENGINE",
        "# ==============================================",
        f'bpy.context.scene.render.engine = "{target_engine}"',
        f"bpy.context.scene.render.resolution_x = {resolution_x}",
        f"bpy.context.scene.render.resolution_y = {resolution_y}",
        f"bpy.context.scene.view_settings.look = 'Standard'",
        "",
        "# ==============================================",
        "# 3. CREATE OBJECTS",
        "# =============================================="
    ]
    
    for obj in objects:
        name = obj.get("name", "Unnamed_Object")
        obj_type = obj.get("type", "")
        
        # Handle location
        loc = obj.get("location", [0, 0, 0])
        if isinstance(loc, dict):
            x, y, z = loc.get("x", 0), loc.get("y", 0), loc.get("z", 0)
        elif len(loc) == 1:
            x, y, z = loc[0], 0, 0
        else:
            x, y, z = loc
        
        code.append(f"# {name}")
        
        # Generate object creation code based on type
        if obj_type == "CUBE":
            size_value = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
            code.append(f"bpy.ops.mesh.primitive_cube_add(size={size_value}, location=({x}, {y}, {z}))")
            bpy_obj_name = name.replace(" ", "_").replace("-", "_")
            code.append(f"{bpy_obj_name} = bpy.context.active_object")
            
        elif obj_type == "SPHERE":
            radius_value = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
            location_str = ", ".join(str(v) for v in loc[:3])
            code.append(f"bpy.ops.mesh.primitive_uv_sphere_add(radius={radius_value}, location=({location_str}))")
            bpy_obj_name = name.replace(" ", "_").replace("-", "_")
            code.append(f"{bpy_obj_name} = bpy.context.active_object")
            
        elif obj_type == "CONE":
            radius_value = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
            location_str = ", ".join(str(v) for v in loc[:3])
            code.append(f"bpy.ops.mesh.primitive_cone_add(radius={radius_value}, location=({location_str}))")
            bpy_obj_name = name.replace(" ", "_").replace("-", "_")
            code.append(f"{bpy_obj_name} = bpy.context.active_object")
            
        elif obj_type == "CYLINDER":
            radius_value = obj.get("scale", 1) if isinstance(obj.get("scale"), (int, float)) else 1.0
            depth_value = obj.get("scale", 1) * 2 if isinstance(obj.get("scale"), (int, float)) else 2.0
            location_str = ", ".join(str(v) for v in loc[:3])
            code.append(f"bpy.ops.mesh.primitive_cylinder_add(radius={radius_value}, depth={depth_value}, location=({location_str}))")
            bpy_obj_name = name.replace(" ", "_").replace("-", "_")
            code.append(f"{bpy_obj_name} = bpy.context.active_object")
            
        elif obj_type == "TORUS":
            major_radius = obj.get("scale", 1) * 2 if isinstance(obj.get("scale"), (int, float)) else 3.0
            minor_radius = obj.get("scale", 1) / 2 if isinstance(obj.get("scale"), (int, float)) else 1.0
            location_str = ", ".join(str(v) for v in loc[:3])
            code.append(f"bpy.ops.mesh.primitive_torus_add(major_radius={major_radius}, minor_radius={minor_radius}, location=({location_str}))")
            bpy_obj_name = name.replace(" ", "_").replace("-", "_")
            code.append(f"{bpy_obj_name} = bpy.context.active_object")
        
        # Handle materials if defined
        material_cfg = obj.get("material", {})
        if material_cfg and config.get("use_nodes", True):
            mat_name = material_cfg.get("name", f"{name}_Material").replace("'", "_")
            code.append("")
            code.append(f"# Apply material to {bpy_obj_name}")
            code.append(f"mat = bpy.data.materials.new(name='{mat_name}')")
            code.append("mat.use_nodes = True")
            code.append("# Set Base Color")
            base_color = material_cfg.get("base_color", [1, 1, 1])
            if isinstance(base_color, dict):
                r, g, b = base_color.get("r", 0), base_color.get("g", 0), base_color.get("b", 0)
            else:
                r, g, b = base_color[0], base_color[1], base_color[2] if len(base_color) > 2 else 1
            code.append(f"mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = ({r}, {g}, {b}, 1.0)")
            
            # Metallic
            metallic = material_cfg.get("metallic", 0.0)
            code.append(f"mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = {metallic}")
            
            # Roughness
            roughness = material_cfg.get("roughness", 0.5)
            code.append(f"mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = {roughness}")
            
            # Transmission (for glass-like materials)
            transmission = material_cfg.get("transmission", 0.0)
            if transmission > 0:
                code.append(f"mat.node_tree.nodes['Principled BSDF'].inputs['Transmission'].default_value = {transmission}")
            

            
            # Add material to object
            code.append(f"{bpy_obj_name}.data.materials.append(mat)")
            code.append("")
    
    # ==============================================
        
    # Skip environment setup for v1 - will add in future versions
    
    # ==============================================
    # 6. SELECTION & ACTIVE OBJECT
    # ==============================================
    code.append("")
    code.append("# ==============================================")
    code.append("# 7. FINALIZE: SELECT ACTIVE OBJECT")
    code.append("# ==============================================")
    
    code.append(f"# Select the last object as active for rendering")
    code.append('bpy.context.view_layer.objects.active = bpy.data.objects[-1] if bpy.data.objects else None')
    
    # ==============================================
    code.append("")
    code.append("# Script generation complete!")
    code.append("print(\"[BMAD] Scene generation completed successfully.\")")
    
    return "\n".join(code)


def run_build(context_file: Path = None, output_dir: Path = None):
    """Main build execution function."""
    # Default paths
    project_root = Path.cwd() / "@bmad-project-context"
    if context_file is None:
        context_file = project_root / "specs" / "scene_config.json"
    
    if output_dir is None:
        output_dir = project_root.parent / "build_output" / "generated_scripts"
    
    print(f"[BMAD AUTO BUILD] Starting build pipeline...")
    print(f"[BMAD AUTO BUILD] Context file: {context_file}")
    print(f"[BMAD AUTO BUILD] Output directory: {output_dir}")
    print("")
    
    # Create output directory if it doesn't exist
    output_dir.mkdir(parents=True, exist_ok=True)
    
    try:
        # Parse context
        print("[BMAD AUTO BUILD] Parsing context specification...")
        spec = parse_context(context_file)
        
        # Load global config
        print("[BMAD AUTO BUILD] Loading project configuration...")
        config = load_config(project_root / "config.yaml")
        
        # Generate script
        print("[BMAD AUTO BUILD] Generating Blender Python script...")
        script_content = generate_blender_script(context_file, config)
        
        # Save script
        output_file = output_dir / "build_scene_latest.py"
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(script_content)
        
        print(f"[BMAD AUTO BUILD] Successfully generated Blender script: {output_file}")
        print("")
        print("[BMAD AUTO BUILD] ==============================================")
        print("[BMAD AUTO BUILD] Build complete! Ready for execution.")
        print("[BMAD AUTO BUILD] ==============================================")
        
        # Print usage instructions
        print("")
        print("To run this script in Blender, use one of these commands:")
        print("")
        print("  # Background render (headless mode):")
        print(f'  blender --background --python "{output_file}"')
        print("")
        print("  # Open in Blender UI:")
        print(f'  blender --python "{output_file}"')
        print("")
        
    except Exception as e:
        print(f"[BMAD AUTO BUILD] Build failed with error: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BMAD Auto Build Pipeline")
    parser.add_argument("--context", "-c", type=Path, help="Path to context spec file")
    parser.add_argument("--output", "-o", type=Path, help="Output directory for generated scripts")
    
    args = parser.parse_args()
    run_build(args.context, args.output)