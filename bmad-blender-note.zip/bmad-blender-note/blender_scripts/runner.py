#!/usr/bin/env python3
"""
BMAD Blender Script Runner
===========================
Helper script to launch Blender with generated scripts.

Usage:
    python runner.py --script build_output/generated_scripts/build_scene_latest.py
    python runner.py --script SCRIPT_PATH --args "blender_args_here"
    
Or from command line:
    blender --background --python build_output/generated_scripts/build_scene_latest.py
"""

import subprocess
import argparse
from pathlib import Path


def run_blender(script_path: str, args: list = None):
    """Execute Blender with the specified script."""
    
    # Default arguments
    base_args = ["blender", "--background"]
    
    if not args:
        args = []
    
    # Add script path
    base_args.append("--python")
    base_args.append(script_path)
    
    # Add any additional arguments
    base_args.extend(args)
    
    try:
        result = subprocess.run(base_args, capture_output=True, text=True)
        
        print(f"[BMAD Runner] Command executed:")
        for arg in base_args:
            print(f"  {arg}")
        print("")
        
        if result.returncode == 0:
            print("[BMAD Runner] ✓ Blender execution completed successfully")
        else:
            print(f"[BMAD Runner] ✗ Blender returned exit code: {result.returncode}")
            
    except FileNotFoundError:
        print("[BMAD Runner] Error: Blender executable not found in PATH")
        print("Please ensure Blender is installed and added to your system PATH.")
    except Exception as e:
        print(f"[BMAD Runner] Execution failed: {e}")


def interactive_mode(script_path: str):
    """Launch Blender in interactive mode with the script loaded."""
    
    base_args = ["blender", "--python", script_path]
    subprocess.run(base_args)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BMAD Blender Script Runner")
    parser.add_argument("--script", "-s", required=True, help="Path to generated Python script")
    parser.add_argument("--interactive", "-i", action="store_true", help="Launch in interactive mode")
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_mode(args.script)
    else:
        run_blender(args.script)
