"""
BMAD Nodes Utility Module
==========================
Common node tree manipulation helpers for Blender Python scripting.
"""

import bpy


def add_light(name, type="AREA", location=(0, 0, 0)):
    """Add a light to the scene."""
    
    if type == "SUN":
        bpy.ops.object.light_add(type='SUN', location=location)
    elif type == "POINT":
        bpy.ops.object.light_add(type='POINT', location=location)
    elif type == "SPOT":
        bpy.ops.object.light_add(type='SPOT', location=location)
    elif type == "AREA":
        bpy.ops.object.light_add(type='AREA', location=location)
    
    obj = bpy.context.active_object
    obj.name = name
    
    return obj


def setup_sun_light(energy=2.0, shadow_softness=15.0):
    """Configure sun light parameters."""
    sun = bpy.data.objects.get("Sun", None)
    if not sun:
        bpy.ops.object.light_add(type='SUN', location=(0, -10, 40))
        sun = bpy.context.active_object
    
    sun.name = "Sun_Light"
    sun.data.energy = energy
    sun.data.shadow_softness = shadow_softness
    
    return sun


def setup_area_light(size=8.0, energy=1.0):
    """Configure area light parameters."""
    # Find or create area light
    area_lights = [obj for obj in bpy.data.objects if obj.type == 'LIGHT' and 
                   obj.data.shadow_type == 'SOLID']
    
    if not area_lights:
        bpy.ops.object.light_add(type='AREA', location=(5, -20, 10))
        area_lights.append(bpy.context.active_object)
    
    # Use the last added or first existing one
    area_light = area_lights[-1]
    area_light.name = "Area_Ambient"
    area_light.data.size = size
    area_light.data.energy = energy
    
    return area_light


def setup_camera(name="Main_Camera", angle="ORTHO"):
    """Configure camera settings."""
    cam = bpy.data.objects.get("Camera", None)
    
    if not cam:
        bpy.ops.object.camera_add(location=(0, 5, 10))
        cam = bpy.context.active_object
    
    cam.name = name
    
    if angle in ["PERSP", "ORTHO"]:
        bpy.context.scene.render.film_transparent = False
        if angle == "ORTHO":
            bpy.context.scene.camera.type = 'ORTHO'
    
    return cam


def setup_output_settings(resolution=(1920, 1080), format="PNG"):
    """Configure render output settings."""
    
    # Resolution
    bpy.context.scene.render.resolution_x = resolution[0]
    bpy.context.scene.render.resolution_y = resolution[1]
    bpy.context.scene.render.film_transparent = False
    
    # Color management
    bpy.context.scene.view_settings.look = "Standard"
    
    return bpy.context.scene.render


def setup_background(color=(0.05, 0.05, 0.08)):
    """Set scene background."""
    if len(color) == 3:
        color = color + [1.0]
    bpy.context.scene.background = color
    
    return "Background set"


# Common node connections

def connect_lighting():
    """Setup common lighting nodes for materials."""
    
    # Add Area Light
    bpy.ops.object.light_add(type='AREA', location=(5, -20, 10))
    area_light = bpy.context.active_object
    area_light.name = "Area_Ambient"
    area_light.data.size = 8.0
    area_light.data.energy = 0.3
    
    # Add Sun Light
    bpy.ops.object.light_add(type='SUN', location=(0, -10, 40))
    sun = bpy.context.active_object
    sun.name = "Sun_Light"
    sun.data.energy = 2.0
    sun.data.shadow_softness = 15.0
    
    return [area_light, sun]


def cleanup_unused_data():
    """Remove unused materials and data blocks."""
    
    # Remove unused materials
    for mat in bpy.data.materials:
        try:
            if not mat.use_nodes:
                continue
            
            links = []
            
            for node in mat.node_tree.nodes:
                if node.users == 0 and node != mat.node_tree.outputs.get("Background"):
                    continue
                # Keep essential nodes
                if node.type in ["ShaderNodeOutput", "ShaderNodeMaterial", 
                                "ShaderNodeBsdfPrincipled"]:
                    continue
            
            links.append(mat.node_tree.links)
            
        except Exception:
            pass
    
    return "Cleanup complete"


def add_environment_nodes():
    """Add common environment nodes to materials."""
    
    # This is a placeholder for more complex node setups
    return "Environment nodes added"
