"""
BMAD Materials Utility Module
==============================
Common material creation helpers for Blender Python scripting.
"""

import bpy


def create_principled_material(name, **kwargs):
    """Create a material with Principled BSDF shader."""
    
    mat = bpy.data.materials.new(name=name)
    mat.use_nodes = True
    
    nodes = mat.node_tree.nodes
    bsdf_node = nodes.get("Principled BSDF", None)
    
    if not bsdf_node:
        bsdf_node = nodes.new(type="ShaderNodeBSDF")
        bsdf_node.location = (-200, 0)
    
    # Set standard inputs
    bsdf_node.inputs['Base Color'].default_value = (1.0, 1.0, 1.0, 1.0)
    bsdf_node.inputs['Metallic'].default_value = kwargs.get('metallic', 0.0)
    bsdf_node.inputs['Roughness'].default_value = kwargs.get('roughness', 0.5)
    
    # Optional inputs
    if 'transmission' in kwargs:
        bsdf_node.inputs['Transmission'].default_value = kwargs['transmission']
    if 'clearcoat' in kwargs:
        bsdf_node.inputs['Clearcoat'].default_value = kwargs['clearcoat']
    if 'specular_ior' in kwargs:
        bsdf_node.inputs['Specular IOR Level'].default_value = kwargs['specular_ior']
    
    return mat


def create_metal_material(name, color=(0.1, 0.1, 0.1), roughness=0.2):
    """Create a metallic material."""
    return create_principled_material(
        name=name,
        base_color=color,
        metallic=1.0,
        roughness=roughness
    )


def create_matte_material(name, color=(0.3, 0.3, 0.3), roughness=0.8):
    """Create a matte (plastic) material."""
    return create_principled_material(
        name=name,
        base_color=color,
        metallic=0.0,
        roughness=roughness
    )


def create_glass_material(name, color=(1.0, 1.0, 1.0), transmission=0.95):
    """Create a glass-like material."""
    return create_principled_material(
        name=name,
        base_color=color,
        metallic=0.0,
        roughness=0.3,
        transmission=transmission
    )


def create_concrete_material(name, color=(0.25, 0.26, 0.28), roughness=0.9):
    """Create a concrete material."""
    return create_principled_material(
        name=name,
        base_color=color,
        metallic=0.0,
        roughness=roughness
    )


def apply_material_to_object(obj, material):
    """Apply a material to an object's mesh data."""
    if obj.data.materials:
        obj.data.materials[0] = material
    else:
        obj.data.materials.append(material)


# Common material presets
PRESETS = {
    "Metal_Gunmetal": create_metal_material("Gunmetal", (0.08, 0.09, 0.12), 0.25),
    "Matte_Gray": create_matte_material("Gray_Matte", (0.3, 0.3, 0.35), 0.8),
    "Glass_Clear": create_glass_material("Glass", (0.95, 0.96, 0.98), 0.95),
    "Concrete_Gritty": create_concrete_material("Concrete", (0.25, 0.26, 0.28), 0.9),
}
