# BMAD AI Development - Blender Pipeline

**Automated Blender Scene Generation from AI Context**

This project implements the BMAD (Blender Model AI Development) framework for creating 3D scenes and assets through automated Python script generation. The system uses a declarative context specification to generate executable Blender Python scripts that procedurally create scenes, materials, lighting, and cameras.

![BMAD Architecture](https://img.shields.io/badge/BMAD-AI%20Dev-blue)
![Blender](https://img.shields.io/badge/Blender-3.0%2B-green)
![Python](https://img.shields.io/badge/Python-3.8%2B-blue)

---

## 📁 Project Structure

```
bmad-blender-note/
├── @bmad-project-context/          # Context definitions & specs (AI input)
│   ├── config.yaml                 # Global project settings
│   ├── prompts/                    # LLM prompt templates
│   ├── schemas/                    # JSON validation schemas
│   └── specs/                      # Active project specifications
│       └── scene_config.json       # Current scene/object definitions
│
├── @bmad-build-auto/               # Build automation system
│   ├── build_pipeline.py           # CLI entry point
│   ├── generators/                 # Code generation modules
│   │   ├── __init__.py
│   │   ├── blender_script_builder.py
│   │   └── context_parser.py
│   ├── validators/                 # Pre-execution validation
│   │   ├── __init__.py
│   │   └── script_validator.py
│   └── templates/                  # Boilerplate scripts
│       └── blender_base_template.py
│
├── build_output/                   # Generated artifacts
│   └── generated_scripts/          # Executable Blender Python scripts
│       └── build_scene_latest.py
│
├── blender_scripts/                # Helper utilities
│   ├── runner.py                   # Script launcher
│   └── utils/                      # Common Blender helpers
│       ├── __init__.py
│       ├── materials.py
│       └── nodes.py
│
└── tests/                          # Automated tests
    ├── test_context_parser.py
    └── test_blender_generator.py
```

---

## 🚀 Quick Start

### 1. Define Your Scene

Edit `@bmad-project-context/specs/scene_config.json`:

```json
{
  "$schema": "../schemas/scene_layout.schema.json",
  "project_name": "My First Scene",
  "version": "1.0.0",
  "target_engine": "CYCLES",
  
  "scene": {
    "background_color": [0.05, 0.05, 0.08],
    "resolution": [1920, 1080]
  },
  
  "objects": [
    {
      "name": "Central_Pedestal",
      "type": "CYLINDER",
      "location": [0.0, 0.0, 1.0],
      "scale": 1.5,
      "material": {
        "name": "Metallic_Dark",
        "base_color": [0.1, 0.1, 0.12],
        "metallic": 0.95,
        "roughness": 0.25
      }
    }
  ]
}
```

### 2. Generate Blender Script

```bash
python @bmad-build-auto/build_pipeline.py
```

This creates `build_output/generated_scripts/build_scene_latest.py`

### 3. Execute in Blender

**Background render (headless):**
```bash
blender --background --python build_output/generated_scripts/build_scene_latest.py
```

**Interactive mode:**
```bash
blender --python build_output/generated_scripts/build_scene_latest.py
```

---

## 📋 Context Specification Reference

### Scene Configuration

```json
{
  "project_name": "Project Name",
  "version": "1.0.0",
  "target_engine": "CYCLES|EUVEE",
  
  "scene": {
    "background_color": [R, G, B],           // [0-1] RGB
    "resolution": [width, height],          // e.g., [1920, 1080]
    "samples": 128,                         // Cycles samples
    "camera_angle": "PERSP|ORTHO"
  },
  
  "objects": [
    {
      "name": "Object_Name",                // Python-safe identifier
      "type": "CUBE|SPHERE|CONE|CYLINDER|TORUS",
      "location": [x, y, z],                // or {"x": 1, "y": 2}
      "scale": 1.0,
      
      "material": {                          // Optional
        "name": "Material_Name",
        "base_color": [R, G, B]              // or {"r": 1, "g": 0.5}
        "metallic": 0.0-1.0,
        "roughness": 0.0-1.0,
        "transmission": 0.0-1.0,             // Glass
        "emissive": true,                    // Optional light-emitting
        "emission_strength": 1.0
      }
    }
  ],
  
  "environment": {                          // Optional
    "fog_enabled": false,
    "sun_light": true,
    "ambient_strength": 0.3,
    "shadow_softness": 15.0
  }
}
```

### Object Types

| Type    | Parameter      | Default           |
|---------|----------------|-------------------|
| CUBE    | `size`         | 1.0               |
| SPHERE  | `radius`       | 1.0               |
| CYLINDER| `radius`, `depth` | `radius` × 2     |
| TORUS   | `major_radius`, `minor_radius` | 3.0, 1.0      |

### Material Properties

| Property          | Type    | Range           | Default    |
|-------------------|---------|------------------|------------|
| base_color        | `[R,G,B]` or `{r,g,b}` | 0-1 (or 0-255)   | [1,1,1]    |
| metallic          | `float` | 0.0 - 1.0        | 0.0        |
| roughness         | `float` | 0.0 - 1.0        | 0.5        |
| transmission      | `float` | 0.0 - 1.0        | 0.0        |
| emissive          | `bool`  | true / false     | false      |

---

## 🔧 Build Pipeline Commands

### Generate Script
```bash
python @bmad-build-auto/build_pipeline.py \
    --context @bmad-project-context/specs/scene_config.json \
    --output build_output/generated_scripts
```

### Quick Run (Default Paths)
```bash
python @bmad-build-auto/build_pipeline.py
```

### Validate Generated Script
```bash
# The pipeline auto-validates, or use standalone:
python -c "from @bmad-build-auto.validators.script_validator import ScriptValidator; v = ScriptValidator(Path('build_output/generated_scripts/build_scene_latest.py')); print(v.get_report())"
```

---

## 📊 Project Flow

```
┌─────────────────────────────────┐
│  @bmad-project-context/        │  ← AI defines scene/specs
│  ├── specs/scene_config.json   │     (objects, materials, lighting)
│  └── config.yaml                │
└──────────────┬──────────────────┘
               ↓
┌─────────────────────────────────┐
│  @bmad-build-auto/              │  ← Pipeline generates Python
│  ├── generators/                │     (from context specs)
│  └── validators/                │
└──────────────┬──────────────────┘
               ↓
┌─────────────────────────────────┐
│  build_output/                  │  ← Generated Blender scripts
│  └── generated_scripts/         │     (ready to execute)
│       └── build_scene_latest.py │
└──────────────┬──────────────────┘
               ↓
┌─────────────────────────────────┐
│  blender --background           │  ← Execute in Blender
│     --python <generated_script> │     (render or generate assets)
└─────────────────────────────────┘
```

---

## 🎨 Sample Scene Specifications

### Simple Geometry
```json
{
  "$schema": "../schemas/scene_layout.schema.json",
  "project_name": "Simple Shapes",
  "version": "1.0.0",
  "target_engine": "CYCLES",
  
  "scene": {
    "background_color": [0.05, 0.05, 0.08],
    "resolution": [1920, 1080]
  },
  
  "objects": [
    {"name": "Cube", "type": "CUBE", "scale": 1.5},
    {"name": "Sphere", "type": "SPHERE", "location": [2, 0, 0]}
  ]
}
```

### Advanced Scene with Materials
See `@bmad-project-context/specs/scene_config.json` in this project for a complete example with:
- Multiple objects (pedestal, columns, glass cap, floor)
- Metallic and matte materials
- Glass transmission material
- Lighting configuration

---

## 🧪 Testing

```bash
# Run unit tests
python -m pytest tests/

# Validate generated script
python -c "from @bmad-build-auto.validators.script_validator import ScriptValidator; print(ScriptValidator(Path('build_output/generated_scripts/build_scene_latest.py')).validate())"
```

---

## 🛠️ Helper Utilities

### Materials Module
```python
from blender_scripts.utils.materials import (
    create_metal_material,
    create_matte_material,
    create_glass_material,
    apply_material_to_object
)

mat = create_metal_material("Gunmetal", (0.1, 0.1, 0.12), 0.25)
obj.data.materials.append(mat)
```

### Nodes Module
```python
from blender_scripts.utils.nodes import (
    add_light, setup_camera, setup_output_settings
)

add_light("Sun_Light", "SUN")
setup_camera(angle="PERSP")
```

---

## 📝 Development Notes

- **Schema Validation**: All context specs should reference `scene_layout.schema.json` for validation.
- **Python Safety**: Object names are automatically sanitized (spaces/hyphens → underscores).
- **Node-based Materials**: All generated materials use Principled BSDF shader nodes.
- **Background Color**: Format is `[R, G, B]` or `[R, G, B, A]`.

---

## 📦 Requirements

```txt
Python >= 3.8
Blender >= 3.0 (with Python API)
```

No external Python packages required - uses only Blender's built-in bpy module.

---

## 🎯 Next Steps

1. **Customize** `@bmad-project-context/specs/scene_config.json` with your scene design
2. **Generate** using `build_pipeline.py`
3. **Iterate** by tweaking context specs and regenerating
4. **Batch Process**: Run multiple scenes in Blender's batch mode

---

## 📄 License

This project is part of the BMAD AI Development framework. All generated Blender scripts are licensed under the same terms as your project.

---

## 💡 Tips

- Use `--background` flag for headless rendering
- Increase `samples` in config for better Cycles renders
- Set `emissive: true` on objects for self-illuminating surfaces
- Glass materials use `transmission > 0` with high `roughness < 0.5`
