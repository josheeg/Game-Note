# Auto-generated Blender Python Script by BMAD AI Build Automation
# Source Context: BMAD Synthetic Environment - First Project
# Version: 1.0.0

import bpy

# ==============================================
# 1. RESET SCENE
# ==============================================
bpy.ops.wm.read_factory_settings(use_empty=True)

# ==============================================
# 2. CONFIGURE RENDER ENGINE
# ==============================================
bpy.context.scene.render.engine = ""CYCLES""
bpy.context.scene.render.resolution_x = 1920
bpy.context.scene.render.resolution_y = 1080
bpy.context.scene.view_settings.look = 'Standard'

# ==============================================
# 3. CREATE OBJECTS
# ==============================================
# Central_Pedestal
bpy.ops.mesh.primitive_cylinder_add(radius=1.5, depth=3.0, location=(0.0, 0.0, 1.0))
Central_Pedestal = bpy.context.active_object

# Apply material to Central_Pedestal
mat = bpy.data.materials.new(name='Metallic_Dark_Gunmetal')
mat.use_nodes = True
# Set Base Color
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.08, 0.09, 0.12, 1.0)
mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.95
mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.25
Central_Pedestal.data.materials.append(mat)

# Left_Column
bpy.ops.mesh.primitive_cube_add(size=1.2, location=(-2.5, -1.2, 0.8))
Left_Column = bpy.context.active_object

# Apply material to Left_Column
mat = bpy.data.materials.new(name='Matte_Gray')
mat.use_nodes = True
# Set Base Color
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.3, 0.3, 0.35, 1.0)
mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.1
mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.8
Left_Column.data.materials.append(mat)

# Right_Column
bpy.ops.mesh.primitive_cube_add(size=1.2, location=(2.5, -1.2, 0.8))
Right_Column = bpy.context.active_object

# Apply material to Right_Column
mat = bpy.data.materials.new(name='Matte_Gray')
mat.use_nodes = True
# Set Base Color
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.3, 0.3, 0.35, 1.0)
mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.1
mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.8
Right_Column.data.materials.append(mat)

# Top_Cap
bpy.ops.mesh.primitive_uv_sphere_add(radius=1.8, location=(0.0, -0.8, 2.8))
Top_Cap = bpy.context.active_object

# Apply material to Top_Cap
mat = bpy.data.materials.new(name='Glass_Transparent')
mat.use_nodes = True
# Set Base Color
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.95, 0.96, 0.98, 1.0)
mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.0
mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.3
mat.node_tree.nodes['Principled BSDF'].inputs['Transmission'].default_value = 0.95
Top_Cap.data.materials.append(mat)

# Floor_Base
bpy.ops.mesh.primitive_cube_add(size=10.0, location=(0.0, -2.5, -1.0))
Floor_Base = bpy.context.active_object

# Apply material to Floor_Base
mat = bpy.data.materials.new(name='Concrete_Gritty')
mat.use_nodes = True
# Set Base Color
mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.25, 0.26, 0.28, 1.0)
mat.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value = 0.0
mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value = 0.9
Floor_Base.data.materials.append(mat)


# ==============================================
# 7. FINALIZE: SELECT ACTIVE OBJECT
# ==============================================
# Select the last object as active for rendering
bpy.context.view_layer.objects.active = bpy.data.objects[-1] if bpy.data.objects else None

# Script generation complete!
print("[BMAD] Scene generation completed successfully.")