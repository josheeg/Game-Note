# Iris Keras Tuner Workflow 🌸🚀

## Overview

This project implements a complete deep neural network hyperparameter optimization pipeline for the Iris dataset using **TensorFlow/Keras** and **Keras Tuner**. The workflow automates model architecture search, training, and verification.

---

## ✨ Features

- ✅ Automatic hyperparameter search (layers, units, dropout, learning rate)
- ✅ Keras Tuner RandomSearch optimization
- ✅ Model persistence in native `.keras` format
- ✅ Load & inference verification
- ✅ Sample prediction demonstrations

---

## 📋 Project Structure

```
bmad-ml-note/
├── note.txt                    # Raw project requirements
├── iris_keras_tuner.py         # Main training script (generated)
├── iris_model.keras            # Trained model output
├── requirements.txt            # Python dependencies
└── README.md                   # This file
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

**Alternative (single command):**
```bash
pip install numpy scipy scikit-learn tensorflow keras keras-tuner
```

### 2. Run the Training Pipeline

```bash
python iris_keras_tuner.py
```

That's it! The script will:
1. Load and preprocess the Iris dataset
2. Search for optimal hyperparameters (up to 10 trials)
3. Train the final model with best parameters
4. Save the model to `iris_model.keras`
5. Verify loading & run sample predictions

---

## 📊 Expected Output

```
=== Step 1: Loading and Preprocessing Data ===
Training samples: 120, Testing samples: 30

=== Step 2: Initializing Keras Tuner ===
[Search space summary...]

=== Step 3: Searching for Optimal Hyperparameters ===
Epoch 1/50 - loss: ... val_loss: ...
... (training output for up to 10 trials)

--- Best Hyperparameters Found ---
Layer 1 Units: 64
Additional Layers: 2
Learning Rate: 0.001

=== Step 4: Building & Training Final Model with Best Hyperparameters ===
Epoch 1/60 - loss: ... val_loss: ...
... (final model training)

Test Accuracy (Before Saving): ~97%

=== Step 5: Saving Model to Disk ===
Model successfully saved to 'iris_model.keras'.

=== Step 6: Loading Saved Model & Running Inference Verification ===
Test Accuracy (Loaded Model): ~97%

--- Sample Predictions ---
Sample 0: Predicted = 'setosa' (Confidence: 1.00), Actual = 'setosa'
...
```

---

## 🎛️ Hyperparameter Search Space

| Parameter | Range/Options |
|-----------|---------------|
| **First Layer Units** | 16, 32, 48, 64 |
| **Additional Layers** | 0-2 (total 1-3 layers) |
| **Dropout Rate** | 0.0, 0.1, 0.2, 0.3 |
| **Learning Rate** | 1e-2, 1e-3, 1e-4 |

---

## 📂 Model Persistence

The trained model is saved in **native Keras format** (`iris_model.keras`):

```python
from tensorflow import keras
loaded_model = keras.models.load_model("iris_model.keras")
predictions = loaded_model.predict(X_test)
```

---

## 🔍 Understanding the Architecture

The DNN structure dynamically adjusts based on search results:

- **Input Layer**: 4 features (sepal length, width, petal length, width)
- **Hidden Layers**: 1-3 dense layers with ReLU activation
- **Output Layer**: 3 units with softmax (one-hot encoded classes)

---

## 🎯 BMAD Workflow Integration

This script is the output of the **@bmad-ml-keras-tuner** automated skill pipeline:

```
note.txt ──→ @bmad-project-context ──→ 
@bmad-brainstorming ──→ @bmad-build-auto ──→ iris_keras_tuner.py
```

### Trigger the Workflow:

You can trigger this workflow by sending:

```markdown
@bmad-ml-keras-tuner
```

Or with a file reference:

```markdown
@bmad-pipeline note.txt
```

---

## 📈 Performance Expectations

| Metric | Expected Range |
|--------|----------------|
| **Validation Accuracy** | 85-92% during search |
| **Test Accuracy** | 96-99% |
| **Training Time** | ~10-30 minutes (depends on machine) |

---

## 🛠️ Customization Tips

### Change Search Strategy

Edit the tuner initialization:

```python
# Replace RandomSearch with other strategies
tuner = kt.RandomSearch(...)  # Original
# or
tuner = kt.Hyperband(...)     # Faster exploration
# or
tuner = kt.NASEnsemble(...)    # More thorough search
```

### Adjust Search Parameters

Modify in `kt.RandomSearch()`:

- `max_trials=10` → increase for deeper search
- `directory='bmad_tuner_logs'` → change log location

### Early Stopping Tuning

Adjust the patience value:

```python
stop_early = keras.callbacks.EarlyStopping(
    monitor='val_loss', 
    patience=10,  # Increase if you have more GPU memory
)
```

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| `ModuleNotFoundError: No module named 'tensorflow'` | Run `pip install tensorflow` |
| CUDA/GPU errors | Install `tensorflow-gpu` or run on CPU |
| Memory errors during training | Reduce `max_trials` to 5 or 7 |
| Slow execution | Use Hyperband tuner instead of RandomSearch |

---

## 📚 References

- [Keras Tuner Documentation](https://keras.io/keras_tuner/)
- [TensorFlow Keras API](https://www.tensorflow.org/api_docs/python/keras)
- [Iris Dataset (UCI)](https://archive.ics.uci.edu/dataset/53/iris)

---

## 📄 License

This project is for educational and research purposes.

---

**Enjoy building your DNN models! 🎉**