import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import keras_tuner as kt
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# Set random seeds for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

def prepare_data():
    """Load and preprocess the Iris dataset."""
    iris = load_iris()
    X = iris.data
    y = iris.target
    
    # Split dataset into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    
    # Feature scaling
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Convert labels to categorical (one-hot encoding)
    y_train_cat = keras.utils.to_categorical(y_train, num_classes=3)
    y_test_cat = keras.utils.to_categorical(y_test, num_classes=3)
    
    return (X_train_scaled, y_train_cat), (X_test_scaled, y_test_cat), scaler, iris.target_names

def build_hypermodel(hp):
    """
    Keras Tuner hypermodel builder function.
    Defines the search space specified in note.txt.
    """
    model = keras.Sequential()
    
    # First Hidden Layer (with dynamic units)
    hp_units = hp.Int('units_layer_1', min_value=16, max_value=64, step=16)
    model.add(layers.Dense(units=hp_units, activation='relu', input_shape=(4,)))
    
    # Optional Additional Hidden Layers (1 to 3 layers total)
    num_layers = hp.Int('num_additional_layers', min_value=0, max_value=2)
    for i in range(num_layers):
        hp_layer_units = hp.Int(f'units_layer_{i+2}', min_value=16, max_value=64, step=16)
        model.add(layers.Dense(units=hp_layer_units, activation='relu'))
        
        # Optional Dropout
        hp_dropout = hp.Float(f'dropout_layer_{i+2}', min_value=0.0, max_value=0.3, step=0.1)
        if hp_dropout > 0:
            model.add(layers.Dropout(rate=hp_dropout))
            
    # Output Layer for 3 Iris classes
    model.add(layers.Dense(3, activation='softmax'))
    
    # Tune learning rate for Adam optimizer
    hp_learning_rate = hp.Choice('learning_rate', values=[1e-2, 1e-3, 1e-4])
    
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=hp_learning_rate),
        loss='categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def main():
    print("=== Step 1: Loading and Preprocessing Data ===")
    (X_train, y_train), (X_test, y_test), scaler, target_names = prepare_data()
    print(f"Training samples: {X_train.shape[0]}, Testing samples: {X_test.shape[0]}")

    print("\n=== Step 2: Initializing Keras Tuner ===")
    tuner = kt.RandomSearch(
        hypermodel=build_hypermodel,
        objective='val_accuracy',
        max_trials=10,
        executions_per_trial=1,
        directory='bmad_tuner_logs',
        project_name='iris_dnn_tuning',
        overwrite=True
    )

    tuner.search_space_summary()

    # Early stopping callback to prevent overfitting
    stop_early = keras.callbacks.EarlyStopping(monitor='val_loss', patience=10)

    print("\n=== Step 3: Searching for Optimal Hyperparameters ===")
    tuner.search(
        X_train, y_train,
        epochs=50,
        validation_split=0.2,
        callbacks=[stop_early],
        verbose=1
    )

    best_hps = tuner.get_best_hyperparameters(num_trials=1)[0]
    print("\n--- Best Hyperparameters Found ---")
    print(f"Layer 1 Units: {best_hps.get('units_layer_1')}")
    print(f"Additional Layers: {best_hps.get('num_additional_layers')}")
    print(f"Learning Rate: {best_hps.get('learning_rate')}")

    print("\n=== Step 4: Building & Training Final Model with Best Hyperparameters ===")
    model = tuner.hypermodel.build(best_hps)
    history = model.fit(
        X_train, y_train,
        epochs=60,
        validation_split=0.2,
        verbose=1
    )

    # Initial evaluation
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    print(f"\nTest Accuracy (Before Saving): {acc * 100:.2f}%")

    print("\n=== Step 5: Saving Model to Disk ===")
    model_path = "iris_model.keras"
    model.save(model_path)
    print(f"Model successfully saved to '{model_path}'.")

    print("\n=== Step 6: Loading Saved Model & Running Inference Verification ===")
    loaded_model = keras.models.load_model(model_path)
    print("Model successfully loaded from disk.")

    # Re-evaluate loaded model
    loaded_loss, loaded_acc = loaded_model.evaluate(X_test, y_test, verbose=0)
    print(f"Test Accuracy (Loaded Model): {loaded_acc * 100:.2f}%")

    # Perform inference on sample test data
    sample_indices = [0, 5, 10]
    sample_data = X_test[sample_indices]
    predictions = loaded_model.predict(sample_data)
    
    print("\n--- Sample Predictions ---")
    for idx, pred in zip(sample_indices, predictions):
        predicted_class = target_names[np.argmax(pred)]
        actual_class = target_names[np.argmax(y_test[idx])]
        print(f"Sample {idx}: Predicted = '{predicted_class}' (Confidence: {np.max(pred):.2f}), Actual = '{actual_class}'")

if __name__ == "__main__":
    main()