---
name: Bug Report
about: Report a bug or issue
title: '[BUG] '
labels: bug
---
## Description
Brief summary of the issue.

## Steps to Reproduce
1. Execute `...`
2. Observe error output.