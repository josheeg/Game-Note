## Summary of Changes
- Linked Spec/Epic:

## Verification Checklist
- [ ] Tests passed (`pytest` with >= 30% coverage)
- [ ] Linting clean (`ruff check src tests`)
- [ ] Type checks clean (`mypy src`)