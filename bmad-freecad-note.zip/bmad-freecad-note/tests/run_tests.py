"""
Test Runner for FreeCAD Component Validation
Executes unit tests for parametric CAD parts.
"""
import os
import sys

# Add src to path for component imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cad.components.mounting_bracket import create_mounting_bracket


def test_mounting_bracket_geometry():
    """Validate mounting bracket geometry properties."""
    params = {
        "length": 100.0,
        "width": 50.0,
        "height": 30.0,
        "thickness": 4.0,
        "hole_diameter": 6.5
    }

    print("[TEST] Creating mounting bracket...")
    doc = create_mounting_bracket(params)

    # Check document has exactly one object
    assert len(doc.Objects) == 1, f"Expected 1 object, got {len(doc.Objects)}"
    print(f"[PASS] Document contains {len(doc.Objects)} object(s)")

    # Validate shape integrity
    obj = doc.Objects[0]
    shape = obj.Shape

    assert shape.isValid(), "Shape is not valid"
    print("[PASS] Shape is valid")

    assert shape.isClosed, "Shape must be closed for STL export"
    print("[PASS] Shape is closed (watertight)")

    # Check bounding box makes sense (approximate)
    bbox = shape.BoundingBox
    print(f"[INFO] Bounding box: {bbox.DiagonalLength:.2f} mm")
    assert bbox.Length > 50, "Bounding box length seems incorrect"
    print("[PASS] Bounding box dimensions reasonable")

    # Check mass properties exist
    mass_properties = obj.Shape.MassProperties
    assert mass_properties is not None, "Mass properties computation failed"
    print(f"[INFO] Volume: {mass_properties.Volume:.2f} mm³")
    print(f"[INFO] Mass: {mass_properties.Mass:.4f} kg (steel @ 7850 kg/m³)")

    print("\n[ALL TESTS PASSED]")
    return doc


if __name__ == "__main__":
    test_mounting_bracket_geometry()
