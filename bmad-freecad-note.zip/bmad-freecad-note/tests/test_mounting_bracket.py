"""
Unit tests for mounting bracket component generator.
Validates geometry, mass properties, and topology integrity.
"""
import unittest
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from cad.components.mounting_bracket import create_mounting_bracket


class TestMountingBracketGeometry(unittest.TestCase):
    """Test suite for mounting bracket geometry."""

    def setUp(self):
        """Create bracket with standard parameters."""
        self.params = {
            "length": 100.0,
            "width": 50.0,
            "height": 30.0,
            "thickness": 4.0,
            "hole_diameter": 6.5
        }
        self.doc = create_mounting_bracket(self.params)

    def test_document_created(self):
        """Document should be created successfully."""
        self.assertIsNotNone(self.doc)
        self.assertEqual(self.doc.Name, "MountingBracket")

    def test_object_count(self):
        """Document should contain exactly one part object."""
        self.assertEqual(len(self.doc.Objects), 1)

    def test_shape_validity(self):
        """Shape must be a valid closed solid."""
        shape = self.doc.Objects[0].Shape
        self.assertTrue(shape.isValid(), "Shape is not valid")
        self.assertTrue(shape.isClosed, "Shape must be closed for STL export")

    def test_mass_properties_exist(self):
        """Mass properties should be computable."""
        obj = self.doc.Objects[0]
        mass_props = obj.Shape.MassProperties
        self.assertIsNotNone(mass_props)
        self.assertTrue(mass_props.Volume > 0, "Volume should be positive")

    def test_bounding_box_dimensions(self):
        """Bounding box should match expected dimensions."""
        bbox = self.doc.Objects[0].Shape.BoundingBox
        # Allow small tolerance for numerical precision
        self.assertAlmostEqual(bbox.Length, self.params["length"], delta=0.1)
        self.assertAlmostEqual(bbox.Height, self.params["height"], delta=0.1)


if __name__ == "__main__":
    unittest.main()
