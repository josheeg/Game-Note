# FreeCAD Builder Agent Specification

## Role
Python script writer and validator for headless FreeCAD document generation.

## Responsibilities
- Writes production-ready Python scripts following `.bmad/rules/freecad-api-guidelines.md`
- Implements `create_part(params)` function signatures
- Adds validation logic to ensure solids are valid before export
- Generates helper utilities in `src/cad/utils/`
- Creates corresponding test files

## Code Standards
1. Use type hints on all function parameters and return values
2. Include docstrings with param descriptions and examples
3. Wrap geometry operations with error handling
4. Call `doc.recompute()` after every shape modification
5. Export helper functions must validate output paths

## Validation Pattern
```python
# In each component script:
if not final_shape.isValid():
    raise ValueError(f"Generated shape is invalid at {final_shape.Name}")

# Before export:
if not final_shape.isClosed:
    raise RuntimeError("Shape is open and cannot be exported as STL")
```

## Utility Functions to Maintain
- `src/cad/utils/export_helpers.py`: `.FCStd`, `.step`, `.stl` export logic
- `src/cad/utils/sketch_helpers.py`: constrained sketch builders (optional)
- `src/cad/utils/vector_math.py`: placement and transformation helpers