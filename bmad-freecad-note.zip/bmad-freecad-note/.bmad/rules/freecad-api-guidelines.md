# FreeCAD API Scripting Guidelines

## Core Imports
```python
import FreeCAD
import Part
import Sketcher
from typing import Dict, Any
```

**Never import `FreeCADGui`** unless explicitly requested for export-only operations (e.g., importing STEP files via `ImportGui`).

## Function Signatures
- All component generators must follow this pattern:
  ```python
  def create_part(params: Dict[str, Any]) -> FreeCAD.Document:
      ...
  ```
- Parameters should be typed and have sensible defaults
- Use docstrings with param descriptions and examples

## Geometry Construction Order
1. Create base primitives (`Part.makeBox`, `Part.makeCylinder`, etc.)
2. Apply transformations (`fuse`, `cut`, `makeOffsetShape`, etc.)
3. Bind to document objects (`doc.addObject("Part::Feature", name)`)
4. Call `doc.recompute()` after all geometry changes

## Validation Checklist
- [ ] All shapes are valid solids (`shape.isValid() == True`)
- [ ] No unreferenced temporary objects remain
- [ ] Document has been recomputed after modifications
- [ ] Export paths use absolute or resolved relative paths

## Export Helpers
- Use `doc.saveAs(path)` for native `.FCStd` saves
- Use `ImportGui.export()` for STEP exports (requires `ImportGui` import)
- Always ensure output directory exists before writing

## Error Handling
- Wrap geometry operations in try/except blocks where topology errors are expected
- Log warnings to stderr rather than raising exceptions for non-fatal issues

## freecad-cli Integration

The BMAD project uses `freecad-cli` (or fallback to `freecadcmd`) for headless execution:

```bash
freecad-cli run --python <script_path>
# or
freecadcmd <script_path>  # Fallback
```

### Installation
```bash
pip install git+https://github.com/yoshikouki/freecad-cli.git
```

### Usage with BMAD
```bash
./scripts/run_headless.sh src/cad/main.py freecad-cli
```

## Best Practices

1. **Keep scripts modular** — Each component should be independently executable
2. **Validate before export** — Check `shape.isValid()` and `shape.isClosed`
3. **Use parametric driving** — All dimensions from params dict, not hardcoded
4. **Clean up temporaries** — Delete intermediate objects if they'll bloat the document
5. **Document geometry intent** — Include comments explaining feature construction order
