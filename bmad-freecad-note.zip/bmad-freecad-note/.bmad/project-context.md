# BMAD Project Context: FreeCAD Python Scripting

## Environment & Tech Stack
- **Target Engine:** FreeCAD (Headless Python 3.x API)
- **Primary Modules:** `FreeCAD`, `Part`, `Sketcher`, `PartDesign`
- **Rule:** Never import `FreeCADGui` in core logic (`src/cad/`). GUI dependencies must be completely decoupled.

## Geometry Rules
1. All dimensions must be parametric and driven by input data structures/dictionaries.
2. Sketches must be fully constrained before extruding/padding.
3. Every component script must expose a `create_part(params: dict) -> FreeCAD.Document` function.
4. Export format requirements: Always generate both native `.FCStd` and neutral `.step` formats.

## Execution Model
- Scripts are executed via headless CLI: `freecadcmd <script_path>` (preferred)
- Alternative: Run Python scripts directly with FreeCAD environment configured
- No interactive dialogs, no user input, no GUI-dependent commands
- All validation must happen in-memory before disk writes
- Use `doc.recompute()` after geometry modifications to ensure clean topology

## Tolerance & Precision
- Base unit: millimeters (mm)
- Standard tolerance: 0.01 mm for dimension checks
- Floating point comparisons should use `Part.Shape.isClosed` and `Shape.isValid()` rather than direct epsilon checks

## Version Control Notes
- FreeCAD API version is abstracted; code uses stable Part module functions
- Export formats are generated at build time via helper utilities

## Current Status
- **Repository initialized:** All directory structure and core files created
- **Pending:** FreeCAD installation or `freecadcmd` CLI availability
- **Next Step:** Install FreeCAD (via package manager or standalone) and verify headless execution
