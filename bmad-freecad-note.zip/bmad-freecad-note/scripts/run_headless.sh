#!/usr/bin/env bash
# Headless script runner for FreeCAD Python execution
# Supports freecad-cli (preferred) or freecadcmd fallback

set -e

SCRIPT_PATH=${1:-"src/cad/main.py"}
FREECAD_TOOL=${2:-"freecad-cli"}  # Use 'freecad-cli' or 'freecadcmd'

echo "[BMAD Build Auto] Using FreeCAD tool: $FREECAD_TOOL"
echo "[BMAD Build Auto] Executing script: $SCRIPT_PATH"

# Execute with the chosen FreeCAD CLI tool
if command -v "$FREECAD_TOOL" &> /dev/null; then
    $FREECAD_TOOL run --python "$SCRIPT_PATH"
else
    echo "[ERROR] FreeCAD tool '$FREECAD_TOOL' not found in PATH."
    echo "[INFO] Install freecad-cli: pip install git+https://github.com/yoshikouki/freecad-cli.git"
    echo "       Or use 'freecadcmd' if installed via standard FreeCAD package."
    exit 1
fi

echo "[BMAD Build Auto] Execution finished successfully."
