# BMAD FreeCAD Automation

Parametric 3D CAD modeling using Python scripts and FreeCAD headless API.

## Quick Start

```bash
# 1. Install freecad-cli (recommended)
pip install git+https://github.com/yoshikouki/freecad-cli.git

# 2. Generate mounting bracket
./scripts/run_headless.sh src/cad/main.py freecad-cli

# 3. Run tests
python tests/run_tests.py
```

## Project Structure

- `.bmad/` — BMAD configuration, agent specs, coding rules
- `specs/` — Component parametric definitions (`.spec.yaml`)
- `src/cad/` — Python scripts generating FreeCAD documents
- `tests/` — Headless geometry validation tests
- `outputs/models/` — Generated CAD files (`.FCStd`, `.step`, `.stl`)

## Execution Pipeline

1. **Grounding**: Read `.bmad/project-context.md` for environment rules
2. **Specification**: Parse `specs/*.spec.yaml` for dimensions
3. **Build**: Run `@bmad-build-auto` to generate scripts in `src/cad/`
4. **Execute**: Call `freecad-cli run --python <script>` to run headless Python
5. **Output**: Generate `.FCStd`, `.step`, and `.stl` files

## Development Workflow

```bash
# 1. Define or update spec
nano specs/mounting_bracket.spec.yaml

# 2. Trigger autonomous build
@bmad-build-auto specs/mounting_bracket.spec.yaml

# 3. Execute with freecad-cli
./scripts/run_headless.sh src/cad/main.py freecad-cli

# 4. Validate
python tests/run_tests.py
```

## Installation Options

### Recommended: freecad-cli
```bash
pip install git+https://github.com/yoshikouki/freecad-cli.git
```

### Alternative: Standard FreeCAD Package
- Windows: `choco install freecad` (provides `freecadcmd`)
- Linux: `sudo apt install freecad` (provides `freecadcmd`)

See [`docs/INSTALL.md`](docs/INSTALL.md) for full installation guide.

## Requirements

- Python 3.8+
- freecad-cli or FreeCAD ≥ 0.21 with headless CLI
- Optional: `numpy`, `scipy` for advanced geometry operations
