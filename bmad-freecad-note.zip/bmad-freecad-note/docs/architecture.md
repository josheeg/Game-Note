# FreeCAD Automation Architecture

## Overview
This repository implements parametric 3D modeling using Python scripts that generate FreeCAD documents programmatically. The architecture separates concerns into:
1. **Context** (`.bmad/`): Rules, guidelines, and agent specifications
2. **Specs** (`specs/`): Parametric dimension definitions per component
3. **Source** (`src/cad/`): Python script modules for FreeCAD document generation
4. **Tests** (`tests/`): Headless validation of generated geometry
5. **Outputs** (`outputs/models/`): Generated CAD artifacts

## Data Flow

```
[specs/*.spec.yaml]
       ↓ (parametric definition)
[src/cad/components/*.py]
       ↓ (Python script generation via @bmad-build-auto)
[scripts/run_headless.sh]
       ↓ (freecadcmd execution)
[outputs/models/(*.step, *.FCStd, *.stl)]
```

## Module Responsibilities

| Directory | Responsibility |
|-----------|---------------|
| `.bmad/` | Agent specs, rules, project context |
| `specs/` | Component parametric definitions |
| `src/cad/components/` | Part generation scripts (e.g., mounting_bracket.py) |
| `src/cad/utils/` | Export helpers, vector math, sketch builders |
| `tests/` | Geometry validation tests |
| `outputs/models/` | Generated CAD files |

## Key Constraints
- All scripts are headless (no `FreeCADGui` imports)
- Every component exposes `create_part(params: dict) -> FreeCAD.Document`
- Exports always generate both `.FCStd` and `.step` formats
