# FreeCAD CLI Installation Guide

## Quick Start (Recommended: freecad-cli)

### Option 1: pip (Python 3.8+)

```bash
pip install git+https://github.com/yoshikouki/freecad-cli.git
```

### Option 2: conda/mamba

```bash
conda create -n freecad python=3.10
conda activate freecad
pip install git+https://github.com/yoshikouki/freecad-cli.git
```

## Alternative: Standard FreeCAD Package

### Windows (Chocolatey)

```powershell
choco install freecad
# This installs freecadcmd.exe
```

### Linux (Ubuntu/Debian)

```bash
sudo add-apt-repository ppa:freecad-team/ppa
sudo apt update
sudo apt install freecad
# Creates /usr/bin/freecadcmd
```

## Verification

Test your installation:

```bash
# For freecad-cli
freecad-cli --version

# Or for freecadcmd (standard package)
freecadcmd --version
```

## Usage with BMAD Project

Once installed, run:

```bash
./scripts/run_headless.sh src/cad/main.py freecad-cli
```

Or use the automatic detection:

```bash
./scripts/run_headless.sh src/cad/main.py  # Auto-detects freecad-cli or freecadcmd
```

## freecad-cli Features

The `freecad-cli` package provides:

- ✅ Headless Python execution via `freecad-cli run --python <script>`
- ✅ No GUI dependencies required
- ✅ Compatible with BMAD parametric workflow
- ✅ Supports modular component scripts

Example usage:
```bash
freecad-cli run --python src/cad/main.py
freecad-cli run --python src/cad/components/mounting_bracket.py
```
