# BMAD FreeCAD Workflow Guide

## Overview

The BMAD (Breakthrough Method for Agile AI-Driven Development) workflow automates parametric CAD design using Python scripts and FreeCAD's headless API.

## Core Concepts

| Component | Purpose | Location |
|-----------|---------|----------|
| **Project Context** | Environment rules, API guidelines | `.bmad/project-context.md` |
| **Agent Specs** | AI agent behavior definitions | `.bmad/agents/*.md` |
| **API Rules** | FreeCAD coding standards | `.bmad/rules/freecad-api-guidelines.md` |
| **Specifications** | Parametric part definitions | `specs/*.spec.yaml` |
| **Component Scripts** | Python → FreeCAD document generators | `src/cad/components/*.py` |
| **Utils** | Export helpers, math libraries | `src/cad/utils/*.py` |
| **Tests** | Geometry validation | `tests/*.py` |
| **Outputs** | Generated CAD artifacts | `outputs/models/` |

## Lifecycle Stages

```
┌─────────────────────┐
│  1. Context          │  → Grounding rules from .bmad/
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│  2. Specification    │  → Parametric definitions in specs/
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│  3. Build (@bmad-   │  → @bmad-build-auto generates scripts
│     build-auto)      │  in src/cad/components/
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│  4. Execute          │  → freecad-cli runs Python script
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│  5. Output           │  → .FCStd, .step, .stl in outputs/
└─────────────────────┘
```

## Standard Commands

### Generate a Component

```bash
# Using freecad-cli (recommended)
./scripts/run_headless.sh src/cad/main.py freecad-cli

# Or auto-detect tool
./scripts/run_headless.sh src/cad/main.py

# Direct command
freecad-cli run --python src/cad/main.py
```

### Run Tests

```bash
python tests/run_tests.py
# Or use unittest discovery
python -m pytest tests/
```

### Trigger Autonomous Build

```bash
# Generate component from spec file
@bmad-build-auto specs/mounting_bracket.spec.yaml
```

## Component Script Pattern

Every component must follow this signature:

```python
def create_part(params: Dict[str, Any]) -> FreeCAD.Document:
    """
    Creates a parametric part.
    
    Args:
        params: Dictionary with dimension parameters
    
    Returns:
        FreeCAD.Document containing the part
    """
    doc = FreeCAD.newDocument("<PartName>")
    
    # 1. Build geometry using Part module
    shape = Part.makeBox(..., ...)
    
    # 2. Modify as needed (fuse, cut, offset)
    shape = shape.fuse(other_shape)
    
    # 3. Bind to document
    obj = doc.addObject("Part::Feature", "<Name>")
    obj.Shape = shape
    
    # 4. Recompute to finalize
    doc.recompute()
    
    return doc
```

## Export Formats

| Format | Extension | Use Case |
|--------|-----------|----------|
| Native FreeCAD | `.FCStd` | Editing, parametric history |
| STEP (neutral) | `.step` / `.stp` | CAD interoperability |
| STL (mesh) | `.stl` | 3D printing, FEM analysis |

All three are generated automatically via `export_helpers.py`.

## Example: Creating a New Component

1. **Define parameters** in `specs/new_part.spec.yaml`:
   ```yaml
   component:
     name: "new_part"
     parameters:
       dimension_a: 50.0
       dimension_b: 25.0
   ```

2. **Generate script** via `@bmad-build-auto` or manually:
   - Create `src/cad/components/new_part.py`
   - Implement `create_new_part(params)` function
   - Add to `src/cad/main.py` in the assembly builder

3. **Execute**:
   ```bash
   freecad-cli run --python src/cad/main.py
   ```

## Validation Checklist

Before committing code:

- [ ] Script uses only headless-compatible imports (no `FreeCADGui`)
- [ ] Function signature matches pattern: `create_<part>(params)`
- [ ] Document is recomputed after geometry modifications
- [ ] Shape validation before export (`shape.isValid()`, `shape.isClosed`)
- [ ] Export helper generates all required formats
- [ ] Unit tests added to `tests/` directory

## Next Steps

1. Install [`freecad-cli`](https://github.com/yoshikouki/freecad-cli)
2. Run first build: `./scripts/run_headless.sh src/cad/main.py freecad-cli`
3. Verify outputs in `outputs/models/`
4. Add new components via specification files
