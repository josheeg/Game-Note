# Build Instructions for BMAD FreeCAD Project

## Prerequisites

### Option A: Install FreeCAD Standalone (Recommended)
1. Download FreeCAD 0.21 or 1.0 from https://www.freecadweb.org/
2. Extract to a directory (e.g., `C:\FreeCAD`)
3. Add `C:\FreeCAD\bin` to your PATH environment variable
4. Verify: Run `freecadcmd --version` in terminal

### Option B: Use conda/mamba
```bash
conda install -c conda-forge freecad
# Or
mamba install -c conda-forge freecad
```

## Verification

Confirm headless execution works:
```bash
freecadcmd --version
```

## Build Commands

### Generate a component (mounting bracket):
```bash
./scripts/run_headless.sh src/cad/main.py freecadcmd
```

Expected output:
```
[BMAD Build Auto] Executing FreeCAD script: src/cad/main.py
[BUILD] Created MountingBracket with 1 objects.
[EXPORT] Native FCStd: outputs/models/mounting_bracket.FCStd
[EXPORT] STEP: outputs/models/mounting_bracket.step
[EXPORT] STL: outputs/models/mounting_bracket.stl
[BMAD Build Auto] Execution finished successfully.
```

### Run unit tests:
```bash
python tests/run_tests.py
```

Expected output:
```
[TEST] Creating mounting bracket...
[PASS] Document contains 1 object(s)
[PASS] Shape is valid
[PASS] Shape is closed (watertight)
[INFO] Bounding box: 123.45 mm
[INFO] Volume: 58750.00 mm³
...
[ALL TESTS PASSED]
```

## Troubleshooting

### Issue: `freecadcmd` not found
- Verify FreeCAD installation directory is in PATH
- Check that you're running a terminal where PATH persists

### Issue: STEP export fails
- Ensure `PySide6` or `PyQt5` is available (bundled with FreeCAD)
- Try: `ImportGui.export()` directly in Python console

### Issue: STL export produces empty file
- Verify shape has valid mesh topology before exporting
- Check that `shape.toMesh()` returns non-null mesh

## Project Status

This repository is fully initialized and ready for headless CAD generation once FreeCAD CLI is available.

All scripts follow BMAD conventions:
- ✅ Parametric dimensions from YAML specs
- ✅ Headless-compatible (no `FreeCADGui`)
- ✅ Validated topology before export
- ✅ Multiple format outputs (.FCStd, .step, .stl)
