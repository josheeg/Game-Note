"""
Main Entry Point for BMAD FreeCAD Assembly Generation
Generates full assemblies from individual component scripts.
"""
import os
import sys

# Add src to path for component imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cad.components.mounting_bracket import create_mounting_bracket
from cad.utils.export_helpers import export_model


def main():
    """Execute the build pipeline."""
    # Load parameters from spec (hardcoded for now, but could read from YAML)
    params = {
        "length": 100.0,
        "width": 50.0,
        "height": 30.0,
        "thickness": 4.0,
        "hole_diameter": 6.5
    }

    # Generate component
    doc = create_mounting_bracket(params)

    # Validate before export
    if not len(doc.Objects) > 0:
        print("ERROR: No objects in document after generation", file=sys.stderr)
        sys.exit(1)

    # Export to outputs directory
    output_dir = os.path.join(os.path.dirname(__file__), "..", "outputs", "models")
    base_name = "mounting_bracket"
    export_paths = export_model(doc, output_dir, base_name)

    print(f"[BMAD] Generated document: {doc.Name}")
    print(f"[BMAD] Exported to:")
    for fmt, path in export_paths.items():
        print(f"  - {fmt.upper()}: {path}")


if __name__ == "__main__":
    main()
