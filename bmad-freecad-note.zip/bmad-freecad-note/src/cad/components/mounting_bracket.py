"""
Mounting Bracket Component Generator for FreeCAD
Generated & managed via @bmad-build-auto

This script creates an L-shaped mounting bracket with a through-hole,
fully parametric and headless-compatible.
"""
import FreeCAD
import Part
from typing import Dict, Any


def create_mounting_bracket(params: Dict[str, Any]) -> FreeCAD.Document:
    """
    Creates a parametric L-bracket in a headless FreeCAD Document.

    Args:
        params: Dictionary with keys:
            - length (float): X dimension of base plate [mm]
            - width (float): Y dimension of base plate [mm]
            - height (float): Z dimension of upright leg [mm]
            - thickness (float): Thickness of bracket in X direction [mm]
            - hole_diameter (float): Diameter of through-hole [mm]
            - hole_spacing (float): Distance from edge to hole center [mm]

    Returns:
        FreeCAD.Document containing the mounting bracket Part::Feature

    Example:
        >>> params = {"length": 100, "width": 50, "height": 30}
        >>> doc = create_mounting_bracket(params)
        >>> len(doc.Objects)  # Should be 1 (the bracket part)
    """
    # Create new headless document
    doc = FreeCAD.newDocument("MountingBracket")

    # Extract parameters with defaults
    length = params.get("length", 100.0)
    width = params.get("width", 50.0)
    height = params.get("height", 30.0)
    thickness = params.get("thickness", 4.0)
    hole_dia = params.get("hole_diameter", 6.5)

    # 1. Create base plate (L-bracket bottom)
    base_plate = Part.makeBox(length, width, thickness)

    # 2. Create upright leg
    upright_leg = Part.makeBox(thickness, width, height)

    # Position upright leg at the edge to form L-shape
    # Offset by length to attach to far edge of base
    offset_vector = FreeCAD.Vector(length - thickness / 2.0, 0, 0)
    upright_leg.Placement = upright_leg.Placement + offset_vector

    # 3. Combine shapes using fusion (creates a single compound)
    bracket_body = base_plate.fuse(upright_leg)

    if not bracket_body.isValid():
        raise RuntimeError("Failed to create valid L-bracket body")

    # 4. Create and position the mounting hole
    # Hole is centered in the upright leg portion
    hole_cylinder = Part.makeCylinder(hole_dia / 2.0, thickness * 3)

    # Position hole at center of upright leg face (length/2 from origin)
    hole_center = FreeCAD.Vector(length / 2.0, width / 2.0, -thickness / 2.0)
    hole_cylinder.Placement = hole_cylinder.Placement + hole_center

    # Cut the hole through the bracket
    final_shape = bracket_body.cut(hole_cylinder)

    if not final_shape.isValid():
        raise RuntimeError("Failed to cut hole — shape may be invalid")

    # 5. Bind geometry to document object
    part_obj = doc.addObject("Part::Feature", "MountingBracket")
    part_obj.Shape = final_shape

    # Recompute to finalize topology
    doc.recompute()

    print(f"[BUILD] Created {doc.Name} with {len(doc.Objects)} objects.")
    return doc


if __name__ == "__main__":
    """Internal execution test for standalone running."""
    sample_params = {
        "length": 100.0,
        "width": 50.0,
        "height": 30.0,
        "thickness": 4.0,
        "hole_diameter": 6.5
    }
    doc = create_mounting_bracket(sample_params)
    print(f"Document {doc.Name} generated successfully with {len(doc.Objects)} objects.")
