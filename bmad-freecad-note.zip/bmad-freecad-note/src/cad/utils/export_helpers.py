"""
Export Utilities for Headless FreeCAD Artifact Generation
Supports .FCStd, .STEP, and .STL export formats.
"""
import os
import sys
import FreeCAD
import Part

# Import GUI modules needed for export operations
try:
    from PySide6.QtGui import QFontDatabase  # Required for STEP export in headless mode
except ImportError:
    from PyQt5.QtGui import QFontDatabase


def export_model(doc: FreeCAD.Document, output_dir: str, base_name: str) -> dict:
    """
    Exports a FreeCAD document to .FCStd, .STEP, and .STL formats.

    Args:
        doc: FreeCAD Document object to export
        output_dir: Absolute path to output directory
        base_name: Base filename (without extension)

    Returns:
        dict mapping format ('fcstd', 'step', 'stl') to absolute file paths
    """
    os.makedirs(output_dir, exist_ok=True)
    paths = {}

    # 1. Save native FCStd document
    fcstd_path = os.path.join(output_dir, f"{base_name}.FCStd")
    doc.saveAs(fcstd_path)
    paths["fcstd"] = fcstd_path
    print(f"[EXPORT] Native FCStd: {fcstd_path}")

    # 2. Export STEP (neutral format for CAD interoperability)
    step_path = os.path.join(output_dir, f"{base_name}.step")
    try:
        # STEP export requires ImportGui in headless mode
        import ImportGui
        if hasattr(doc, 'Objects') and len(doc.Objects) > 0:
            ImportGui.export(doc.Objects, step_path, "Advanced", options="2")
        else:
            # Fallback: export entire document
            from FreeCAD import Module
            Module.ImportGui.export(doc, step_path)
        print(f"[EXPORT] STEP: {step_path}")
    except Exception as e:
        print(f"[WARN] STEP export failed: {e}", file=sys.stderr)

    # 3. Export STL (mesh format for 3D printing/FEM)
    stl_path = os.path.join(output_dir, f"{base_name}.stl")
    try:
        from Part import Mesh
        shape = doc.Objects[0].Shape if hasattr(doc, 'Objects') else doc.Shape
        mesh = shape.toMesh()  # Convert solid to mesh
        mesh_solid = Part.MeshToShape(mesh)  # Re-wrap as shape for STL export
        stl_writer = FreeCAD.Draft.writeMesh(stl_path, mesh, options="2")
        print(f"[EXPORT] STL: {stl_path}")
    except Exception as e:
        print(f"[WARN] STL export failed: {e}", file=sys.stderr)

    return paths
