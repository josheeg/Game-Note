"""Blender module tests."""

import pytest
from pathlib import Path
from unittest.mock import Mock, patch
import subprocess


# Import Blender command functions
from src.cli.commands.blender_cmd import (
    validate_blender_installation,
    generate_scene,
    export_scene,
)


class TestBlenderValidation:
    """Tests for Blender installation validation."""
    
    def test_validate_blender_not_found(self):
        """Test that validation raises error when Blender is not found."""
        with pytest.raises(FileNotFoundError) as exc_info:
            validate_blender_installation()
        
        # Check error message contains helpful information
        assert 'Blender' in str(exc_info.value)
        assert 'PATH' in str(exc_info.value)


@patch('src.cli.commands.blender_cmd._execute_blender_script')
def test_generate_scene(mock_execute):
    """Test scene generation with mocked subprocess."""
    
    # Mock successful execution
    mock_execute.return_value = Mock(returncode=0, stderr='')
    
    # This will fail because Blender is not installed, but we're testing the logic
    with pytest.raises(FileNotFoundError) as exc_info:
        generate_scene("test_scene")
    
    assert 'Blender' in str(exc_info.value)


@patch('src.cli.commands.blender_cmd._execute_blender_script')
def test_export_scene(mock_execute):
    """Test scene export functionality."""
    
    # Mock successful execution
    mock_execute.return_value = Mock(returncode=0, stderr='')
    
    try:
        # Will fail without Blender but tests the export logic
        export_scene("test_scene", format="obj")
    except Exception as e:
        # We expect this to fail at import time if bpy not available
        assert 'export' in str(e).lower() or 'blender' in str(e).lower()


class TestBlenderImport:
    """Test that Blender module can be imported."""
    
    def test_module_import(self):
        """Verify Blender command module imports correctly."""
        import src.cli.commands.blender_cmd
        
        # Check that key functions exist
        assert hasattr(src.cli.commands.blender_cmd, 'validate_blender_installation')
        assert hasattr(src.cli.commands.blender_cmd, 'generate_scene')
        assert hasattr(src.cli.commands.blender_cmd, 'export_scene')


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
