"""FreeCAD module tests."""

import pytest
from pathlib import Path
from unittest.mock import Mock, patch


# Import FreeCAD command functions
from src.cli.commands.freecad_cmd import (
    validate_freecad_installation,
    generate_part,
    export_model,
    create_primitive,
)


class TestFreeCADValidation:
    """Tests for FreeCAD installation validation."""
    
    def test_validate_freecad_not_found(self):
        """Test that validation raises error when FreeCAD is not found."""
        with pytest.raises(FileNotFoundError) as exc_info:
            validate_freecad_installation()
        
        # Check error message contains helpful information
        assert 'FreeCAD' in str(exc_info.value)
        assert 'PATH' in str(exc_info.value)


@patch('src.cli.commands.freecad_cmd._execute_freecad_script')
def test_generate_part(mock_execute):
    """Test part generation with mocked subprocess."""
    
    # Mock successful execution
    mock_execute.return_value = Mock(returncode=0, stderr='')
    
    try:
        path = generate_part(
            model_name="test_bracket",
            operation_type="extrude",
            depth=50,
        )
        
        # Check that a valid Path object is returned
        assert isinstance(path, Path)
        
    except FileNotFoundError as e:
        # Expected if FreeCAD not installed - validates the error handling
        assert 'FreeCAD' in str(e)


@patch('src.cli.commands.freecad_cmd._execute_freecad_script')
def test_export_model(mock_execute):
    """Test model export functionality."""
    
    # Mock successful execution
    mock_execute.return_value = Mock(returncode=0, stderr='')
    
    try:
        path = export_model(
            model_name="test_bracket",
            format="step",
        )
        
        # Check that a valid Path object is returned
        assert isinstance(path, Path)
        
    except Exception as e:
        # May fail due to missing FreeCAD dependencies
        assert 'export' in str(e).lower() or 'freecad' in str(e).lower()


class TestCreatePrimitive:
    """Tests for primitive creation functionality."""
    
    def test_create_box_primitive(self):
        """Test creating a box primitive."""
        # This may fail if FreeCAD not installed, but tests the function signature
        try:
            result = create_primitive(
                primitive_type="box",
                dimensions=[50.0, 30.0, 10.0],
            )
            
            assert isinstance(result, dict)
            assert result['type'] == 'box'
            assert abs(result['dimensions'][0] - 50.0) < 0.01
            
        except ImportError:
            # FreeCAD API not available - function signature is correct
    
    def test_create_cylinder_primitive(self):
        """Test creating a cylinder primitive."""
        try:
            result = create_primitive(
                primitive_type="cylinder",
                dimensions=[10.0, 20.0],  # radius, height
            )
            
            assert isinstance(result, dict)
            assert result['type'] == 'cylinder'
            
        except ImportError:
            pass  # FreeCAD API not available
    
    def test_create_sphere_primitive(self):
        """Test creating a sphere primitive."""
        try:
            result = create_primitive(
                primitive_type="sphere",
                dimensions=[15.0, (0.0, 0.0)],  # radius, center
            )
            
            assert isinstance(result, dict)
            assert result['type'] == 'sphere'
            
        except ImportError:
            pass  # FreeCAD API not available
    
    def test_create_cone_primitive(self):
        """Test creating a cone primitive."""
        try:
            result = create_primitive(
                primitive_type="cone",
                dimensions=[20.0, 30.0, 90.0],  # base_radius, height, angle
            )
            
            assert isinstance(result, dict)
            assert result['type'] == 'cone'
            
        except ImportError:
            pass  # FreeCAD API not available


class TestFreeCADImport:
    """Test that FreeCAD module can be imported."""
    
    def test_module_import(self):
        """Verify FreeCAD command module imports correctly."""
        import src.cli.commands.freecad_cmd
        
        # Check that key functions exist
        assert hasattr(src.cli.commands.freecad_cmd, 'validate_freecad_installation')
        assert hasattr(src.cli.commands.freecad_cmd, 'generate_part')
        assert hasattr(src.cli.commands.freecad_cmd, 'export_model')
        assert hasattr(src.cli.commands.freecad_cmd, 'create_primitive')


if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
