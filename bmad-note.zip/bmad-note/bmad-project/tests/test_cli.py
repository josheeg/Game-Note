"""CLI integration and unit tests."""

import pytest
from typer.testing import CliRunner
from src.cli.main import app


runner = CliRunner()


def test_cli_help():
    """Test that CLI help is displayed correctly."""
    result = runner.invoke(app, ['--help'])
    
    assert result.exit_code == 0
    assert 'Usage' in result.output
    assert 'hello' in result.output.lower()
    assert 'version' in result.output.lower()


def test_hello_command():
    """Test greeting functionality."""
    result = runner.invoke(app, ['--name', 'BMAD'])
    
    assert result.exit_code == 0
    assert 'Hello, BMAD!' in result.output


def test_hello_without_name():
    """Test greeting without name argument."""
    result = runner.invoke(app)
    
    assert result.exit_code == 0
    assert 'Hello' in result.output


def test_version_command():
    """Test version display."""
    result = runner.invoke(app, ['version'])
    
    assert result.exit_code == 0
    assert 'BMAD Modular CLI' in result.output


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
