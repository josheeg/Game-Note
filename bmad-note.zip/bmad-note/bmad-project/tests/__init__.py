"""Test suite for BMAD Modular CLI."""
