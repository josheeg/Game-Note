# BMAD Modular CLI Application

A unified command-line interface integrating Blender 3D generation, FreeCAD parametric modeling, and deep learning forecasting into a single modular Python application.

## Features

- **Blender Module**: Generate 3D scenes and assets using Blender's Python API (BPY)
- **FreeCAD Module**: Parametric CAD design automation via FreeCAD CLI
- **ML Forecasting Module**: Deep Neural Network time-series prediction with Keras Tuner hyperparameter optimization
- **Unified CLI**: Single binary entry point with organized subcommands

## Architecture

```
bmad-project/
├── note.txt                        # Source requirements
├── pyproject.toml                  # Dependencies and tooling config
├── README.md                       # This file
├── docs/                           # Technical documentation
│   ├── prd.md                      # Product Requirements Document
│   ├── architecture.md             # System architecture specs
│   └── stories/                    # User story specifications
├── src/                            # Application source code
│   ├── cli/                        # Command-line interface
│   │   ├── main.py                 # CLI entrypoint (Typer)
│   │   └── commands/               # Sub-command modules
│   ├── cad/                        # 3D modeling engine
│   │   ├── blender/                # Blender BPY scripts
│   │   └── freecad/                # FreeCAD CLI automation
│   └── ml/                         # Deep learning forecasting
└── tests/                          # Automated test suite (≥30% coverage)
```

## Prerequisites

### System Requirements

- **Python 3.10+**: Recommended 3.10, 3.11, or 3.12
- **Blender 3.x**: Required for the Blender module (system installation)
- **FreeCAD 0.x or 1.x**: Required for CAD generation (system installation)

### Installation

#### 1. Clone or Copy Project

```bash
cd bmad-project
```

#### 2. Create Virtual Environment

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

#### 3. Install Dependencies

```bash
pip install -e ".[dev]"
```

#### 4. Install System Dependencies

**For Blender:**
```bash
# Download from https://www.blender.org/download/
# Ensure Blender is added to your system PATH
```

**For FreeCAD:**
```bash
# Download from https://www.freecad.org/
# Or use conda: conda install -c conda-forge freecad
```

## Usage

### Available Commands

```bash
# Help
bmad-cli --help

# Blender Module Commands
bmad-cli cad generate-blender <scene_name> [options]
bmad-cli cad export-blender --format {obj,fbx,gltf} <scene_name>

# FreeCAD Module Commands
bmad-cli cad generate-freecad <model_name> [options]
bmad-cli cad export-freecad --format {step,iges,stl} <model_name>

# ML Forecasting Commands
bmad-cli forecast train <dataset_path> --epochs <int> --batch_size <int>
bmad-cli forecast evaluate <model_path> --dataset <data_path>
bmad-cli forecast predict --model <model_path> --input <features>
```

### Examples

#### Generate Blender Scene

```bash
bmad-cli cad generate-blender "product_render" \
    --resolution 1920x1080 \
    --lighting studio \
    --export format gltf
```

#### Create FreeCAD Part

```bash
bmad-cli cad generate-freecad "bracket_v1" \
    --extrusion_depth 50 \
    --material aluminum_6061
```

#### Train ML Forecasting Model

```bash
bmad-cli forecast train sales_data.csv \
    --epochs 100 \
    --batch_size 32 \
    --split 0.8 \
    --metrics "mae,rmse,mape"
```

### Configuration Files

Create YAML configuration files for advanced options:

```yaml
# config.blender.yaml
resolution: [1920, 1080]
lighting: studio
materials:
  diffuse: true
  roughness: 0.5
export:
  format: gltf
  path: ./output/scenes/

# config.freecad.yaml
kernel: OCCT
units: mm
operations:
  extrude: true
  loft: false
materials:
  aluminum_6061: true
```

Use with commands: `bmad-cli cad generate-blender --config config.blender.yaml`

## Project Structure Details

### CLI Module (`src/cli/`)

- **main.py**: Typer-based CLI entrypoint with subcommand routing
- **commands/blender_cmd.py**: Blender subprocess invocation and scene orchestration
- **commands/freecad_cmd.py**: FreeCAD script execution and model generation
- **commands/forecast_cmd.py**: ML training pipeline and inference interface

### CAD Module (`src/cad/`)

- **blender/**: BPY scene builders, material systems, export utilities
  - `scene_builder.py`: Core Blender Python API integration
- **freecad/**: FreeCAD modeling operations and feature tree management
  - `model_builder.py`: Parametric part design automation

### ML Module (`src/ml/`)

- **model.py**: Deep neural network architecture (MLP, LSTM variants)
- **tuner.py**: Keras Tuner hyperparameter optimization interface
- **dataset.py**: Data loading, normalization, train/validation/test splitting
- **predict.py**: Model inference and prediction interface

### Test Structure (`tests/`)

- `test_cli.py`: CLI command parsing and integration tests
- `test_blender.py`: Blender module unit and integration tests
- `test_freecad.py`: FreeCAD module unit and integration tests
- `test_ml.py`: ML model training, evaluation, and prediction tests

## Testing

### Run All Tests

```bash
pytest tests/ -v
```

### Run with Coverage Report

```bash
pytest tests/ --cov=src --cov-report=html
```

### Test Targets

- Minimum 30% code coverage required
- Unit tests for all public API methods
- Integration tests for CLI command execution
- Mock subprocess calls where appropriate

## Development Workflow

### Phase 1: Context & Discovery
- Review `note.txt` and existing architecture documents
- Understand domain requirements for each module

### Phase 2: Requirements Specification
- Refer to `docs/prd.md` for functional and non-functional requirements

### Phase 3: Architecture Review
- Check `docs/architecture.md` for system design and module contracts

### Phase 4: Story Implementation
- See `docs/stories/` for detailed user story specifications

### Phase 5: Build & QA Loop
```bash
# Run automated build with linting
bmad-cli --help

# Run code quality checks
black src/ tests/
isort src/ tests/
flake8 src/ tests/
mypy src/
```

## Development Guidelines

### Code Style

- Follow PEP 8 guidelines
- Use type hints where beneficial (gradual adoption)
- Include docstrings for all public APIs
- Keep functions focused and single-purpose

### Testing Standards

- Write tests alongside feature code
- Aim for meaningful test coverage
- Use pytest fixtures for setup/teardown
- Mock external dependencies (Blender, FreeCAD subprocesses)

### Documentation

- Maintain accurate docstrings
- Update README when adding new features
- Document all command-line arguments

## Troubleshooting

### Blender Module Issues

**Error: No module named 'bpy'**
```bash
# bpy is a Python wrapper. Install manually:
pip install bpy
# OR use subprocess with system blender:
bmad-cli cad generate-blender <name>  # Uses Blender directly via subprocess
```

**Error: Blender not found in PATH**
```bash
# Add Blender installation directory to PATH:
setx PATH "%PATH%;C:\Program Files\Blender Foundation\Blender 4.0"  # Windows
export PATH="/opt/blender:$PATH"  # Linux/Mac
```

### FreeCAD Module Issues

**Error: No module named 'freecad'**
```bash
# Install FreeCAD Python wrapper or use system FreeCAD directly
pip install freecad-python-wrapper
# OR configure commands to use FreeCAD's embedded Python
```

### ML Module Issues

**Import errors with TensorFlow/Keras**
```bash
# Ensure GPU support (optional but recommended)
pip install tensorflow[and-cuda]

# Check TensorFlow version compatibility
python -c "import tensorflow as tf; print(tf.__version__)"
```

## License

MIT License - See LICENSE file for details

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes following the coding style
4. Add/update tests
5. Submit a pull request

## Roadmap

- [ ] Add Blender shader programming support
- [ ] Implement FreeCAD constraint solver integration
- [ ] Add multi-GPU ML training support
- [ ] Create visualization dashboard for forecasting results
- [ ] Add Docker containerization for deployment

---

**Need Help?** Check the `docs/` folder for detailed specifications and architecture documentation.