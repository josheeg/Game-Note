# BMAD Modular CLI - Quick Start Guide

## Installation Steps

### Step 1: Clone Project

```bash
cd bmad-project
```

### Step 2: Create Virtual Environment

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# OR: venv\Scripts\activate  # Windows
```

### Step 3: Install Dependencies

```bash
pip install -e ".[dev]"
```

This installs:
- CLI framework (Typer)
- Blender integration (subprocess wrapper)
- FreeCAD integration (subprocess wrapper)  
- ML framework (TensorFlow, Keras, Keras Tuner)
- Development tools (pytest, black, flake8)

### Step 4: Install System Dependencies

**For Blender:**
```bash
# Windows
cd https://www.blender.org/download/windows/

# Linux/Mac
sudo apt-get install blender  # Debian/Ubuntu
# OR download from https://www.blender.org/download/macos/
```

Add Blender to PATH (Windows):
```powershell
$env:Path += ";C:\Program Files\Blender Foundation\Blender 4.0"
```

**For FreeCAD:**
```bash
# Windows
cd https://www.freecad.org/download/windows/

# Linux/Mac
sudo apt-get install freecad  # Debian/Ubuntu
```

Add FreeCAD to PATH (Windows):
```powershell
$env:Path += ";C:\Program Files\FreeCAD"
```

## Running the CLI

### Help

```bash
bmad-cli --help
# Shows all available commands
```

### Test Installation

```bash
bmad-cli version
# Should output: BMAD Modular CLI v0.1.0
```

### Blender Commands

```bash
# Generate a 3D scene
bmad-cli cad generate-blender product_render \
    --resolution 1920x1080 \
    --lighting studio

# Export to OBJ format
bmad-cli cad export-blender --format obj product_render
```

### FreeCAD Commands

```bash
# Generate a parametric part
bmad-cli cad generate-freecad bracket_v1 \
    --operation extrude \
    --depth 50

# Export to STEP format
bmad-cli cad export-freecad --format step bracket_v1
```

### ML Commands

```bash
# Train forecasting model
bmad-cli forecast train sales_data.csv \
    --epochs 100 \
    --batch-size 32

# Make predictions
bmad-cli forecast predict \
    --model best_model.h5 \
    --input test_features.csv
```

## Running Tests

### All Tests

```bash
pytest tests/ -v
```

### With Coverage Report

```bash
pytest tests/ --cov=src --cov-report=html
# Opens coverage.html in browser
```

Expected coverage: ≥30%

## Project Structure

```
bmad-project/
├── note.txt                 # Source requirements
├── pyproject.toml           # Dependencies and config
├── README.md                # Full documentation
├── docs/                    # Technical specifications
│   ├── prd.md               # Product Requirements Document
│   ├── architecture.md      # System architecture
│   └── stories/             # User story specifications
│       ├── story_01_cli.md
│       ├── story_02_blender.md
│       ├── story_03_freecad.md
│       └── story_04_ml.md
├── src/                     # Source code
│   ├── cli/                 # CLI interface
│   ├── cad/                 # CAD generation engine
│   │   ├── blender/         # Blender module
│   │   └── freecad/         # FreeCAD module
│   └── ml/                  # ML forecasting engine
└── tests/                   # Test suite
```

## Architecture Highlights

### Modular Design
- CLI (`src/cli/`) - Unified command-line interface
- CAD (`src/cad/`) - 3D modeling operations
  - Blender module - Scene generation and export
  - FreeCAD module - Parametric design automation
- ML (`src/ml/`) - Deep learning forecasting

### Subprocess Architecture
- External tools (Blender, FreeCAD) invoked via subprocess
- Clean separation of concerns
- No dependency conflicts between tools

### Type-Safe Code
- Full type hints throughout codebase
- Pydantic models for configuration
- Automatic error propagation from subprocess calls

## Next Steps

1. **Read the Documentation**: Check `docs/prd.md` and `docs/architecture.md`

2. **Review User Stories**: See `docs/stories/` for detailed specifications

3. **Run Tests**: Verify your environment with `pytest tests/ -v`

4. **Explore Code**: All modules are well-documented with examples

5. **Customize**: Use YAML configuration files for advanced options

## Getting Help

- Check error messages in terminal
- Review documentation in `docs/` folder
- Run individual module tests to isolate issues
- Ensure Blender and FreeCAD are in PATH

## License

MIT License - See LICENSE file for details

---

**Happy creating!** 🚀