"""BMAD Modular CLI - Main entry point."""
