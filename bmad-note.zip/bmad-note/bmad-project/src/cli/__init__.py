"""CLI module for BMAD Modular CLI application."""
