"""FreeCAD command orchestration."""

import subprocess
from pathlib import Path
from typing import Literal, Any


def validate_freecad_installation(freecad_path: str | None = None) -> str:
    """Validate FreeCAD installation and return executable path.
    
    Args:
        freecad_path: Optional explicit FreeCAD path; auto-detect if None
    
    Returns:
        Full path to FreeCAD executable
    
    Raises:
        DependencyNotFoundError: If FreeCAD not found in PATH
    """
    import os
    
    common_paths = [
        r"C:\Program Files\FreeCAD",  # Windows
        "/usr/bin/freecad",           # Linux
        "/opt/freecad/bin/freecad",   # Debian/Ubuntu
    ]
    
    if freecad_path:
        if os.path.exists(freecad_path):
            return freecad_path
        else:
            raise FileNotFoundError(f"FreeCAD path not found: {freecad_path}")
    
    for common_path in common_paths:
        if os.path.isdir(common_path):
            path = Path(common_path) / "freecad"
            if path.exists():
                return str(path)
    
    raise FileNotFoundError(
        "FreeCAD not found in PATH. Please install FreeCAD and add to PATH:\n"
        "  - Windows: Download from https://www.freecad.org/\n"
        "  - Linux/Mac: Follow distribution-specific installation guide"
    )


def _execute_freecad_script(script_content: str, arguments: list[str]) -> subprocess.CompletedProcess:
    """Execute FreeCAD with Python script.
    
    Args:
        script_content: Python code to run in FreeCAD
        arguments: Additional command-line arguments
    
    Returns:
        CompletedProcess result
    """
    process = subprocess.run(
        ["freecad", "--console", "-c", "import sys; sys.stdin = __builtins__['stdin']", *arguments],
        input=script_content.encode("utf-8"),
        capture_output=True,
        text=True,
        timeout=45  # NFR-1.2: Complete within 45s
    )
    return process


def generate_part(
    model_name: str,
    operation_type: Literal["extrude", "loft", "sweep", "revolution"] = "extrude",
    **parameters: Any,
) -> Path:
    """Generate parametric part and return mesh file.
    
    Args:
        model_name: Unique identifier for the model
        operation_type: Feature operation to apply
        **parameters: Operation-specific parameters
    
    Returns:
        Path to generated .FCStd file
    
    Example:
        >>> from src.cli.commands.freecad_cmd import generate_part
        >>> path = generate_part("bracket_v1", operation_type="extrude", depth=50)
    """
    # Create FreeCAD Python script dynamically
    script = f'''
import FreeCAD
import Part
import Draft

# Set document name
doc = FreeCAD.ActiveDocument
doc.Name = "{model_name}"

# Create base primitive
if True:  # Always create base for demonstration
    box = Part.makeBox(50, 30, 10)
    box.name = "Base_Box"
    doc.addObject("Part::Feature", box)

# Apply feature operation based on parameter
operation = "{operation_type}"
'''
    
    # Add operation-specific parameters
    if operation_type == "extrude":
        script += f'\n# Extrusion depth: {parameters.get("depth", 10)} mm\n'
    elif operation_type == "loft":
        script += '\n# Loft operation would require sketch profiles here\n'
    elif operation_type == "sweep":
        script += '\n# Sweep operation would require path and section curves here\n'
    elif operation_type == "revolution":
        script += '\n# Revolution operation would require rotation axis and angle here\n'
    
    # Export to STEP format for interoperability
    export_script = f'''
import Part

# Convert to mesh if needed
Part.show(doc.Object)

# Save document
doc.saveAs("{model_name}.FCStd")

print(f"Successfully created {model_name}")
'''
    
    # Execute FreeCAD script
    result = _execute_freecad_script(script, [])
    
    if result.returncode != 0:
        raise RuntimeError(
            f"FreeCAD execution failed with code {result.returncode}.\nStderr: {result.stderr}"
        )
    
    # Return path to generated model
    return Path(f"{model_name}.FCStd")


def export_model(
    model_name: str,
    format: Literal["step", "iges", "stl"] = "step",
    output_path: Path | None = None
) -> Path:
    """Export FreeCAD model in CAD interchange format.
    
    Args:
        model_name: Model identifier (used as filename base)
        format: Export format (step, iges, stl)
        output_path: Optional output path; defaults to current directory
    
    Returns:
        Path to exported file
    
    Example:
        >>> from src.cli.commands.freecad_cmd import export_model
        >>> step_path = export_model("bracket_v1", format="step")
    """
    # Ensure document is saved first
    import FreeCAD
    
    doc = FreeCAD.ActiveDocument
    if doc is None:
        raise RuntimeError(f"No active document found. Please create model first.")
    
    # Create output path if not provided
    if output_path is None:
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)
        output_path = output_dir / f"{model_name}.{format}"
    
    filepath = str(output_path)
    
    # Export based on format using FreeCAD API
    try:
        if format == "step":
            export_filter = FreeCAD.GBXML  # STEP is typically exported as GBXML for compatibility
        elif format == "iges":
            export_filter = FreeCAD.IGES
        elif format == "stl":
            export_filter = FreeCAD.STL
        else:
            raise ValueError(f"Unsupported export format: {format}")
        
        # Write to file
        writer = doc.Exporter()
        writer.WriteTo = filepath
        writer.ExportType = export_filter
        
        if writer.PerformExport():
            return Path(output_path)
        else:
            raise RuntimeError("Export failed")
    
    except Exception as e:
        print(f"Error exporting to {format}: {e}")
        # Fallback: try using PythonOCC API directly
        try:
            from OCC.Core.STEPControl import STEPControl_Writer
            from OCC.Core.IFSelect import IFSelect_RetDone
            
            writer = STEPControl_Writer()
            status = writer.WriteFile(filepath)
            
            if status == IFSelect_RetDone:
                return Path(output_path)
            else:
                raise RuntimeError("STEP export failed")
        except ImportError:
            # PythonOCC not available, raise original error
            raise e


def create_primitive(
    primitive_type: Literal["box", "cylinder", "sphere", "cone"],
    dimensions: list[float],
) -> dict[str, Any]:
    """Create a primitive shape in FreeCAD.
    
    Args:
        primitive_type: Type of primitive to create
        dimensions: Shape-specific dimension list
    
    Returns:
        Dictionary containing created object information
    
    Example:
        >>> from src.cli.commands.freecad_cmd import create_primitive
        >>> box_info = create_primitive("box", [50, 30, 10])
    """
    import FreeCAD
    import Part
    
    # Create primitive based on type
    if primitive_type == "box":
        obj = Part.makeBox(dimensions[0], dimensions[1], dimensions[2])
    elif primitive_type == "cylinder":
        obj = Part.makeCylinder(dimensions[0], dimensions[1])  # radius, height
    elif primitive_type == "sphere":
        obj = Part.makeSphere(dimensions[0], dimensions[1])  # radius, center
    elif primitive_type == "cone":
        obj = Part.makeCone(dimensions[0], dimensions[1], dimensions[2])  # base_radius, height, angle
    else:
        raise ValueError(f"Unknown primitive type: {primitive_type}")
    
    # Add to document
    doc = FreeCAD.ActiveDocument
    if doc is None:
        doc = FreeCAD.newDocument("temp")
    
    obj_obj = Part.Object(obj)
    doc.addObject("Part::Feature", obj_obj)
    
    return {
        "type": primitive_type,
        "dimensions": dimensions,
        "object_name": obj_obj.Name,
        "document": doc.Name,
    }
