"""Blender command orchestration."""

import subprocess
from pathlib import Path
from typing import Literal, tuple


def validate_blender_installation(blender_path: str | None = None) -> str:
    """Validate Blender installation and return executable path.
    
    Args:
        blender_path: Optional explicit Blender path; auto-detect if None
    
    Returns:
        Full path to Blender executable
    
    Raises:
        DependencyNotFoundError: If Blender not found in PATH
    """
    import os
    
    common_paths = [
        r"C:\Program Files\Blender Foundation\Blender 4.0",  # Windows
        r"C:\Program Files (x86)\Blender Foundation\Blender",  # Windows older
        "/usr/bin/blender",  # Linux
        "/usr/local/bin/blender",  # Mac/Linux
    ]
    
    if blender_path:
        if os.path.exists(blender_path):
            return blender_path
        else:
            raise FileNotFoundError(f"Blender path not found: {blender_path}")
    
    for common_path in common_paths:
        # Handle directory (add executable name)
        if os.path.isdir(common_path):
            path = Path(common_path) / "blender"
            if path.exists():
                return str(path)
    
    raise FileNotFoundError(
        "Blender not found in PATH. Please install Blender and add to PATH:\n"
        "  - Windows: Download from https://www.blender.org/download/\n"
        "  - Linux/Mac: Follow distribution-specific installation guide"
    )


def _execute_blender_script(script_content: str, arguments: list[str]) -> subprocess.CompletedProcess:
    """Execute Blender with Python script.
    
    Args:
        script_content: Python code to run in Blender
        arguments: Additional command-line arguments
    
    Returns:
        CompletedProcess result
    """
    process = subprocess.run(
        ["blender", "-b", "--python-execute", "-", *arguments],
        input=script_content.encode("utf-8"),
        capture_output=True,
        text=True,
        timeout=60  # NFR-1.1: Complete within 60s
    )
    return process


def generate_scene(
    scene_name: str,
    resolution: tuple[int, int] = (1920, 1080),
    lighting: Literal["studio", "three_point", "ambient"] = "studio"
) -> Path:
    """Generate a Blender scene and return output path.
    
    Args:
        scene_name: Unique identifier for the scene
        resolution: Target resolution (width, height)
        lighting: Lighting preset name
    
    Returns:
        Path to generated .blend file
    
    Example:
        >>> from src.cli.commands.blender_cmd import generate_scene
        >>> path = generate_scene("my_scene", resolution=(1920, 1080))
    """
    # Create Blender Python script dynamically
    script = f'''
import bpy
import os

# Set scene name
bpy.ops.scene.new(name="{scene_name}")

# Set resolution
bpy.context.scene.render.resolution_x = {resolution[0]}
bpy.context.scene.render.resolution_y = {resolution[1]}

# Apply lighting preset based on parameter
if "{lighting}" == "studio":
    # Studio lighting setup
    bpy.ops.object.light_add(type="AREA")
    area_light = bpy.context.object
    area_light.name = "Studio_Key_Light"
    area_location = bpy.data.objects.new("Key_Light_Location", None)
    
elif "{lighting}" == "three_point":
    # Three-point lighting
    pass

elif "{lighting}" == "ambient":
    # Ambient only
    pass

# Add default cube for rendering
bpy.ops.mesh.primitive_cube_add(location=(0, 0, 1))
obj = bpy.context.object
obj.name = "Scene_Mesh"

# Write scene file
filepath = os.path.expanduser("./output/" + "{scene_name}.blend")
bpy.ops.wm.save_as_mainfile(filepath=filepath)
'''
    
    # Execute Blender script
    result = _execute_blender_script(script, [])
    
    if result.returncode != 0:
        raise RuntimeError(
            f"Blender execution failed with code {result.returncode}.\nStderr: {result.stderr}"
        )
    
    # Return path to generated scene
    output_dir = Path("output")
    output_dir.mkdir(exist_ok=True)
    return output_dir / f"{scene_name}.blend"


def export_scene(
    scene_name: str,
    format: Literal["obj", "fbx", "gltf"],
    output_path: Path | None = None
) -> Path:
    """Export Blender scene in specified format.
    
    Args:
        scene_name: Scene identifier (used as filename base)
        format: Export format (obj, fbx, gltf)
        output_path: Optional output path; defaults to current directory
    
    Returns:
        Path to exported file
    
    Example:
        >>> from src.cli.commands.blender_cmd import export_scene
        >>> obj_path = export_scene("my_scene", format="obj")
    """
    import bpy
    from pathlib import Path
    
    # Ensure scene is saved first
    bpy.ops.wm.save_as_mainfile(filepath="./output/" + scene_name + ".blend")
    
    # Create output path if not provided
    if output_path is None:
        output_dir = Path("output")
        output_dir.mkdir(exist_ok=True)
        output_path = output_dir / f"{scene_name}.{format}"
    
    # Export based on format
    file_extension = {
        "obj": ".obj",
        "fbx": ".fbx",
        "gltf": ".glb" if Path(output_path).suffix == ".gltf" else ""
    }
    
    filepath = str(output_path)
    
    export_operation = None
    
    if format == "obj":
        export_operation = bpy.ops.export_scene.obj
    elif format == "fbx":
        export_operation = bpy.ops.export_scene.fbx
    elif format == "gltf":
        # GLB is binary, use gltf for text
        export_operation = bpy.ops.export_scene.gltf
    
    if export_operation:
        export_operation(filepath=filepath, include_custom_properties=False)
    
    return Path(output_path)
