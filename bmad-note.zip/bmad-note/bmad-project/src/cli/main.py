"""CLI entry point using Typer framework."""

import typer
from pathlib import Path


# Create Typer app
app = typer.Typer(
    name="bmad-cli",
    help="Modular CLI for 3D generation and ML forecasting",
    add_completion=False,
)


@app.command()
def version():
    """Display version information."""
    print("BMAD Modular CLI v0.1.0")


@app.command()
def hello(name: str | None = typer.Option(None, "--name", "-n")):
    """Greet someone by name."""
    if name:
        typer.echo(f"Hello, {name}!")
    else:
        typer.echo("Hello, world!")


if __name__ == "__main__":
    app()
