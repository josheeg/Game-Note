"""Blender module implementation."""
