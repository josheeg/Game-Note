"""Neural network architecture for time-series forecasting."""

import tensorflow as tf
from tensorflow import keras
from typing import List, Literal, Optional
import numpy as np


class ForecastingModel(keras.Model):
    """Base forecasting model with configurable architecture.
    
    This class supports both MLP and LSTM architectures for different types
    of time-series patterns.
    
    Example:
        >>> # Create MLP model
        >>> model = ForecastingModel(
        ...     input_dim=10,
        ...     hidden_dims=[64, 32],
        ...     use_lstm=False,
        ... )
        >>> model.compile(optimizer='adam', loss='mse')
    """
    
    def __init__(
        self,
        input_dim: int,
        hidden_dims: List[int],
        use_lstm: bool = False,
        lstm_units: int = 64,
        dropout_rate: float = 0.2,
        activation: Literal["relu", "tanh", "sigmoid"] = "relu",
        learning_rate: float = 0.001,
    ):
        """Initialize model with specified architecture.
        
        Args:
            input_dim: Number of input features/timesteps
            hidden_dims: List of hidden layer dimensions for MLP
            use_lstm: Whether to use LSTM layers (for sequential patterns)
            lstm_units: Number of LSTM units (if use_lstm=True)
            dropout_rate: Dropout rate for regularization (0.0-1.0)
            activation: Activation function type ('relu', 'tanh', 'sigmoid')
            learning_rate: Learning rate for optimizer
        """
        super().__init__()
        
        self.input_dim = input_dim
        self.hidden_dims = hidden_dims
        self.use_lstm = use_lstm
        self.lstm_units = lstm_units
        self.dropout_rate = dropout_rate
        self.activation = activation
        self.learning_rate = learning_rate
    
    def build(self, input_shape):
        """Build model architecture dynamically.
        
        Args:
            input_shape: Shape of input tensor (unused after first call)
        """
        layers = [keras.Input(shape=(input_shape[0],)) if len(input_shape) > 1 
                  else keras.Input(shape=input_shape)]
        
        # Add LSTM layers if specified, otherwise use Dense layers
        if self.use_lstm:
            for units in self.hidden_dims:
                lstm_layer = keras.layers.LSTM(
                    units, 
                    return_sequences=True if len(self.hidden_dims) > np.array([self.hidden_dims].__len__()) else False,
                    activation=self.activation
                )
                layers.append(lstm_layer)
        else:
            for units in self.hidden_dims:
                dense_layer = keras.layers.Dense(
                    units,
                    activation=self.activation
                )
                layers.append(dense_layer)
        
        # Add dropout layers for regularization (between hidden layers)
        if self.dropout_rate > 0 and len(self.hidden_dims) > 1:
            for _ in range(len(self.hidden_dims) - 1):
                layers.append(keras.layers.Dropout(self.dropout_rate))
        
        # Output layer (single value for regression)
        output_layer = keras.layers.Dense(1, activation='linear')
        layers.append(output_layer)
        
        self.model = keras.Model(layers[0], layers[-1])
    
    def compile(
        self,
        optimizer: str = "adam",
        learning_rate: float | None = None,
        loss: str = "mse",
        metrics: list[str] | None = None,
    ):
        """Compile model with specified configuration.
        
        Args:
            optimizer: Optimizer name ('adam', 'sgd', 'rmsprop')
            learning_rate: Optional learning rate override
            loss: Loss function name for regression
            metrics: List of metric names to track
        """
        lr = learning_rate if learning_rate is not None else self.learning_rate
        
        if optimizer.lower() == "adam":
            opt = keras.optimizers.Adam(learning_rate=lr)
        elif optimizer.lower() == "sgd":
            opt = keras.optimizers.SGD(learning_rate=lr)
        elif optimizer.lower() == "rmsprop":
            opt = keras.optimizers.RMSprop(learning_rate=lr)
        else:
            opt = keras.optimizers.Adam(learning_rate=lr)
        
        # Define metrics
        if metrics is None:
            metrics = ["mae"]  # Default to MAE for forecasting
        
        self.compile(optimizer=opt, loss=loss, metrics=metrics)
    
    def call(self, inputs):
        """Forward pass through the model.
        
        Args:
            inputs: Input tensor of shape (batch_size, ...)
        
        Returns:
            Output tensor with predictions
        """
        return self.model(inputs)
    
    def train_step(self, data):
        """Custom training step for better logging.
        
        Args:
            data: Tuple of (inputs, targets)
        
        Returns:
            Dictionary of metrics logged during this step
        """
        x, y = data
        
        with tf.GradientTape() as tape:
            predictions = self(x, training=True)
            loss_value = self.compiled_loss(y, predictions, regularization_losses=self.losses)
        
        # Compute gradients and apply optimizer updates
        batch_metrics_logs = self.compiled_metrics.compute(metrics={'loss': loss_value})
        batch_predictions = self.compiled_metrics.update_state(y, predictions)
        
        grads = tape.gradient(loss, self.trainable_variables)
        self.optimizer.apply_gradients(zip(grads, self.trainable_variables))
        
        # Update metrics
        self.compiled_metrics.update_state(y, predictions)
        
        # Return metrics for logging
        logs = {'loss': loss_value}
        logs.update({k: round(v.numpy(), 4) for k, v in self.compiled_metrics.result().items()})
        
        return logs
