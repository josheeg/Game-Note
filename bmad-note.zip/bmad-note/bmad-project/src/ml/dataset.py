"""Data loading, preprocessing, and splitting for time-series forecasting."""

import pandas as pd
from pathlib import Path
from typing import Tuple, Optional
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import numpy as np


class TimeSeriesDataset:
    """Time-series data loading with normalization and splitting.
    
    This class handles CSV file parsing, timestamp handling, feature normalization,
    and chronological train/test splits to prevent data leakage.
    
    Example:
        >>> dataset = TimeSeriesDataset(
        ...     csv_path="sales_data.csv",
        ...     timestamp_column="date",
        ...     split_ratio=0.8,
        ... )
        >>> X_train, y_train, X_test, y_test = dataset.prepare()
    """
    
    def __init__(
        self,
        csv_path: str,
        timestamp_column: str = "timestamp",
        target_columns: Optional[list[str]] = None,
        split_ratio: float = 0.8,
        time_gap: int = 0,
    ):
        """Initialize dataset from CSV file.
        
        Args:
            csv_path: Path to CSV file with time-series data
            timestamp_column: Name of column containing timestamps
            target_columns: Columns to predict (None for all numeric columns)
            split_ratio: Train/test split ratio (e.g., 0.8 = 80% train, 20% test)
            time_gap: Time gap between train and test to prevent look-ahead bias
        """
        self.csv_path = csv_path
        self.timestamp_col = timestamp_column
        self.target_cols = target_columns
        self.split_ratio = split_ratio
        self.time_gap = time_gap
        
        self.df: Optional[pd.DataFrame] = None
        self.scaler: Optional[MinMaxScaler] = None
        self.train_data: Optional[Tuple[np.ndarray, np.ndarray]] = None
        self.test_data: Optional[Tuple[np.ndarray, np.ndarray]] = None
    
    def load_csv(self) -> pd.DataFrame:
        """Load CSV file and parse timestamp as index.
        
        Returns:
            DataFrame with timestamp set as index
        
        Raises:
            FileNotFoundError: If CSV file doesn't exist
            ValueError: If timestamp column not found or invalid dates
        """
        path = Path(self.csv_path)
        
        if not path.exists():
            raise FileNotFoundError(f"CSV file not found: {self.csv_path}")
        
        # Load CSV with datetime parsing
        self.df = pd.read_csv(
            self.csv_path,
            parse_dates=[self.timestamp_col],
            index_col=self.timestamp_col,
        )
        
        return self.df
    
    def normalize_features(self) -> Tuple[pd.DataFrame, MinMaxScaler]:
        """Normalize all numeric features.
        
        Returns:
            Tuple of (normalized dataframe, fitted scaler object)
        """
        # Select numeric columns only
        numeric_cols = self.df.select_dtypes(include=[np.number]).columns.tolist()
        
        if not numeric_cols:
            raise ValueError("No numeric columns found in the dataset")
        
        # Fit scaler on training portion only (prevent data leakage)
        train_split = int(len(self.df) * self.split_ratio)
        train_df = self.df.iloc[:train_split]
        
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.df[numeric_cols] = self.scaler.fit_transform(
            self.df[numeric_cols].values
        )
        
        return self.df, self.scaler
    
    def handle_missing_values(self) -> pd.DataFrame:
        """Handle missing values with forward-fill interpolation.
        
        This preserves temporal ordering by filling gaps with previous values.
        
        Returns:
            DataFrame with missing values handled
        
        Raises:
            ValueError: If backward fill would look ahead in time
        """
        if self.df is None:
            self.load_csv()
        
        # Forward fill to preserve temporal order (no look-ahead)
        self.df = self.df.fillna(method='ffill')
        
        return self.df
    
    def train_test_split(self) -> Tuple[Tuple[np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]]:
        """Split data chronologically (not randomly).
        
        This is crucial for time-series forecasting to prevent look-ahead bias.
        
        Returns:
            Tuple of ((X_train, y_train), (X_test, y_test)) as numpy arrays
        
        Raises:
            ValueError: If not enough samples for split
        """
        if self.df is None or self.scaler is None:
            raise RuntimeError("Dataset must be loaded and normalized before splitting")
        
        n_samples = len(self.df)
        train_size = int(n_samples * self.split_ratio)
        
        # Split indices chronologically
        train_idx = range(train_size)
        test_idx = range(train_size + self.time_gap, n_samples)  # Add time gap
        
        if len(test_idx) == 0:
            raise ValueError(
                f"Insufficient samples for train/test split. "
                f"Need at least {train_size + 1} samples, have {n_samples}"
            )
        
        # Extract features and targets
        X_train = self.df.iloc[train_idx].values
        y_train = self.df.iloc[train_idx][self.target_cols or self.df.columns.tolist()].values
        
        X_test = self.df.iloc[test_idx].values
        y_test = self.df.iloc[test_idx][self.target_cols or self.df.columns.tolist()].values
        
        return (X_train, y_train), (X_test, y_test)
    
    def prepare(self) -> Tuple[Tuple[np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]]:
        """Complete preprocessing pipeline.
        
        Returns:
            Tuple of ((X_train, y_train), (X_test, y_test)) as numpy arrays
        
        Example:
            >>> X_train, y_train, X_test, y_test = dataset.prepare()
            >>> model.fit(X_train, y_train)
            >>> predictions = model.predict(X_test)
        """
        # Load and normalize
        self.load_csv()
        self.handle_missing_values()
        self.normalize_features()
        
        # Split chronologically
        return self.train_test_split()


def load_and_split_data(
    csv_path: str,
    train_ratio: float = 0.8,
) -> Tuple[Tuple[np.ndarray, np.ndarray], Tuple[np.ndarray, np.ndarray]]:
    """Convenience function to load and split time-series data.
    
    Args:
        csv_path: Path to CSV file
        train_ratio: Fraction of data for training (default 0.8)
    
    Returns:
        Tuple of ((X_train, y_train), (X_test, y_test)) as numpy arrays
    
    Example:
        >>> train_data, test_data = load_and_split_data("sales.csv", train_ratio=0.8)
        >>> # train_data = (X_train, y_train)
        >>> # test_data = (X_test, y_test)
    """
    dataset = TimeSeriesDataset(csv_path=csv_path, split_ratio=train_ratio)
    return dataset.prepare()
