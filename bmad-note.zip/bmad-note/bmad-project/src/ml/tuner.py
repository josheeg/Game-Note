"""Keras Tuner integration for hyperparameter optimization."""

import keras_tuner as kt
from typing import Any, Dict
import numpy as np
from .model import ForecastingModel
import tensorflow as tf


class HyperparameterTuner(kt.KTuner):
    """Keras Tuner wrapper for forecasting model optimization.
    
    This class provides an interface to search over hyperparameters
    and find the optimal configuration for time-series forecasting models.
    
    Example:
        >>> tuner = HyperparameterTuner(hyperparams={'hidden_dims': [16, 32]})
        >>> tuner.search(train_data, validation_data, epochs=10)
        >>> best_model = tuner.get_best_models(1)[0]
    """
    
    def __init__(self, hyperparams: dict[str, Any], max_epochs: int = 5):
        """Initialize tuner with search space definition.
        
        Args:
            hyperparams: Dictionary of hyperparameter names to search spaces
            max_epochs: Maximum epochs per trial (for early stopping)
        """
        super().__init__(kt.RandomSearch(10))  # Default 10 trials
        self.search_space = hyperparams
        self.max_epochs = max_epochs
    
    def build_model(self, hp, input_dim, use_lstm=False):
        """Build model given hyperparameter values from the search space.
        
        Args:
            hp: Hyperparameter object from Keras Tuner
            input_dim: Number of input features
            use_lstm: Whether to use LSTM architecture
        
        Returns:
            Compiled Keras model ready for training
        """
        # Sample hidden dimensions from search space
        hidden_dims = hp.Choice("hidden_dims", [16, 32, 64, 128])
        
        # Sample learning rate (log scale for better coverage)
        learning_rate = hp.Float("learning_rate", 0.0001, 0.1, sampling="log")
        
        # Sample dropout rate
        dropout_rate = hp.Float("dropout_rate", 0.1, 0.5, sampling="linear")
        
        # Optionally sample LSTM vs MLP architecture
        use_lstm_bool = hp.Choice("use_lstm", [True, False])
        
        # Build model with sampled hyperparameters
        model = ForecastingModel(
            input_dim=input_dim,
            hidden_dims=[hidden_dims] * 2,  # Two hidden layers for simplicity
            use_lstm=use_lstm_bool,
            dropout_rate=dropout_rate,
            activation="relu",
            learning_rate=learning_rate,
        )
        
        # Compile with sampled hyperparameters
        model.compile(
            optimizer='adam',
            loss='mse',
            metrics=['mae'],
        )
        
        return model
    
    def objective(self, model):
        """Define objective function for hyperparameter search.
        
        This function trains a model and returns a metric to optimize
        (lower is better, since we're minimizing validation loss).
        
        Args:
            model: Model instance with sampled hyperparameters
        
        Returns:
            Validation loss after training (lower is better)
        """
        # Train model with early stopping
        history = model.fit(
            self.train_data,
            validation_data=self.val_data,
            epochs=self.max_epochs,
            batch_size=32,
            verbose=0,  # Suppress output during search
        )
        
        # Return validation loss (we want to minimize this)
        return history.history["val_loss"][0]
    
    def set_search_space(self, space: dict[str, Any]):
        """Set custom search space configuration.
        
        Args:
            space: Dictionary of hyperparameter names to Keras Tuner parameter objects
        """
        self.search_space = space
    
    def run_search(
        self,
        train_data: np.ndarray | tf.data.Dataset,
        val_data: np.ndarray | tf.data.Dataset,
        max_trials: int = 10,
        project_name: str = "forecasting_tuner",
    ) -> Dict[str, Any]:
        """Run hyperparameter search.
        
        Args:
            train_data: Training data as numpy array or TF dataset
            val_data: Validation data as numpy array or TF dataset
            max_trials: Maximum number of trials to run
            project_name: Name for tuner project (for saving results)
        
        Returns:
            Dictionary containing:
                - best_model: Best model instance
                - best_hp: Best hyperparameter values
                - best_epochs: Number of epochs for best model
                - validation_loss: Validation loss of best model
        """
        # Save data references
        self.train_data = train_data
        self.val_data = val_data
        
        # Run search
        studies = self.search(
            space=self.search_space,
            objective=self.objective,
            max_trials=max_trials,
            directory=f"{project_name}",
            project_name=project_name,
        )
        
        # Get best model
        best_models = studies.get_best_models(num_models=1)
        best_model = best_models[0]
        
        # Get best hyperparameters
        best_hp = studies.get_best_hyperparameter(1)  # Get first (best) hyperparam
        
        return {
            'best_model': best_model,
            'best_hp': best_hp,
            'best_epochs': len(studies.hypermodel),
            'validation_loss': best_models[0].get('val_loss', np.nan),
        }


def tune_hyperparameters(
    train_data: np.ndarray,
    val_data: np.ndarray,
    input_dim: int,
    max_trials: int = 10,
) -> tuple[keras.Model, Dict[str, Any]]:
    """Convenience function to run hyperparameter tuning.
    
    Args:
        train_data: Training data (X_train, y_train) tuple
        val_data: Validation data (X_val, y_val) tuple
        input_dim: Number of input features
        max_trials: Maximum trials for search
    
    Returns:
        Tuple of (best_model, tuning_results dictionary)
    
    Example:
        >>> X_train, y_train = load_and_split_data()
        >>> X_val, y_val = validation_split(X_train, y_train)
        >>> best_model, results = tune_hyperparameters(
        ...     train_data=(X_train, y_train),
        ...     val_data=(X_val, y_val),
        ...     input_dim=X_train.shape[1],
        ... )
    """
    tuner = HyperparameterTuner({})
    
    # Sample a reasonable search space
    search_space = {
        "hidden_dims": kt.IntChoice([16, 32, 64, 128]),
        "learning_rate": kt.FloatChoice([0.001, 0.01, 0.1], sampling="log"),
        "dropout_rate": kt.FloatChoice([0.1, 0.2, 0.3]),
        "use_lstm": kt.BooleanChoice([True, False]),
    }
    
    tuner.set_search_space(search_space)
    
    # Run search
    results = tuner.run_search(
        train_data=train_data,
        val_data=val_data,
        max_trials=max_trials,
    )
    
    return results['best_model'], results
