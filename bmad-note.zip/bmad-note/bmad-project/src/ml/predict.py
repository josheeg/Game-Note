"""Model inference and prediction interface."""

import tensorflow as tf
from pathlib import Path
from typing import Optional, Tuple, Union
import numpy as np


class Predictor:
    """Model inference and prediction interface.
    
    This class handles loading trained models from disk and making predictions
    on new data for time-series forecasting tasks.
    
    Example:
        >>> predictor = Predictor(model_path="best_model.h5")
        >>> predictions, confidence_intervals = predictor.predict(input_features)
    """
    
    def __init__(self, model_path: str):
        """Initialize predictor with trained model.
        
        Args:
            model_path: Path to saved Keras model (HDF5 or SavedModel format)
        
        Raises:
            FileNotFoundError: If model file doesn't exist
            ValueError: If model cannot be loaded
    
        Example:
            >>> from src.ml.predict import Predictor
            >>> predictor = Predictor("best_model.h5")
            >>> pred = predictor.predict(X_test)
        """
        model_path_obj = Path(model_path)
        
        if not model_path_obj.exists():
            raise FileNotFoundError(f"Model file not found: {model_path}")
        
        try:
            self.model = tf.keras.models.load_model(str(model_path_obj))
            print(f"Loaded model from: {model_path}")
        except Exception as e:
            raise ValueError(f"Failed to load model from {model_path}: {e}")
    
    def predict(
        self,
        input_features: Union[np.ndarray, pd.DataFrame],
        time_steps: int = 1,
        batch_size: int = 32,
    ) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Make predictions on input features.
        
        Args:
            input_features: Preprocessed input features (numpy array or DataFrame)
            time_steps: Number of future steps to predict (for multi-step forecasting)
            batch_size: Batch size for prediction
        
        Returns:
            Tuple of (predictions, confidence_intervals):
                - predictions: Array of shape (n_samples,) with predicted values
                - confidence_intervals: None or array of shape (n_samples, 2) with 
                  [lower_bound, upper_bound] if uncertainty estimation is available
        
        Example:
            >>> X_test = preprocess_test_data()
            >>> predictions, _ = predictor.predict(X_test)
            >>> # predictions contains forecasted values
        """
        # Convert to numpy array if DataFrame
        if isinstance(input_features, pd.DataFrame):
            input_features = input_features.values
        
        # Ensure 2D array for batch prediction
        if len(input_features.shape) == 1:
            input_features = np.expand_dims(input_features, axis=0)
        
        # Make predictions
        predictions = self.model.predict(
            input_features,
            batch_size=batch_size,
            verbose=0,  # Suppress output
        ).numpy()
        
        # Return with confidence intervals if available (not implemented yet)
        return predictions, None
    
    def predict_multiple_steps(
        self,
        history: np.ndarray,
        steps: int = 5,
        batch_size: int = 32,
    ) -> np.ndarray:
        """Generate multi-step forecasts recursively.
        
        This method generates predictions for multiple future time steps by
        using previous predictions as input (recursive forecasting).
        
        Args:
            history: Historical data array of shape (timesteps, features)
            steps: Number of future steps to forecast
            batch_size: Batch size for prediction
        
        Returns:
            Array of shape (steps,) with predicted future values
        
        Example:
            >>> history = last_30_days_sales()  # Shape: (30, n_features)
            >>> forecasts = predictor.predict_multiple_steps(history, steps=7)
            >>> # Forecasts contains 1-step ahead predictions for next 7 days
        """
        forecasts = []
        
        # Get last timestep from history
        timesteps = history.shape[0]
        
        # Forecast one step at a time (recursive)
        for step in range(steps):
            # Use most recent timesteps as input
            input_window = history[-timesteps:, :]
            
            # Make single-step prediction
            forecast = self.predict(input_window)[0][0]  # Get first (and only) value
            
            forecasts.append(forecast)
        
        return np.array(forecasts)
    
    def evaluate(
        self,
        X_test: np.ndarray,
        y_test: np.ndarray,
        metrics: Optional[list[str]] = None,
    ) -> dict[str, float]:
        """Evaluate model on test data.
        
        Args:
            X_test: Test input features
            y_test: True target values
            metrics: List of additional metrics to compute (default: MAE)
        
        Returns:
            Dictionary of metric names to scores
        
        Example:
            >>> metrics = predictor.evaluate(X_test, y_test)
            >>> print(f"MAE: {metrics['mae']:.4f}")
        """
        # Make predictions
        predictions = self.predict(X_test)[0]
        
        # Compute metrics manually (without additional dependencies)
        mae = np.mean(np.abs(predictions - y_test))
        rmse = np.sqrt(np.mean((predictions - y_test) ** 2))
        
        results = {
            'mae': mae,
            'rmse': rmse,
        }
        
        # Add additional metrics if requested
        if metrics:
            for metric in metrics:
                if metric == "mape":  # Mean Absolute Percentage Error
                    percentage_errors = np.abs((y_test - predictions) / y_test) * 100
                    results[metric] = float(np.mean(percentage_errors))
        
        return results
    
    def export(
        self,
        output_path: str,
        format: str = "hdf5",
        include_optimizer: bool = True,
    ):
        """Export model to specified format.
        
        Args:
            output_path: Path to save exported model
            format: Export format ('hdf5' or 'saved_model')
            include_optimizer: Whether to save training optimizer state
        
        Example:
            >>> predictor.export("deploy_model.h5", format="hdf5")
            >>> # Model is now ready for deployment
        """
        output_path_obj = Path(output_path)
        
        if format == "saved_model":
            self.model.save(str(output_path_obj), save_format="saved_model")
        else:  # hdf5
            self.model.save(str(output_path_obj))
        
        print(f"Model exported to: {output_path}")


def load_predictor(model_path: str) -> Predictor:
    """Convenience function to load a trained model.
    
    Args:
        model_path: Path to trained model file
    
    Returns:
        Predictor instance ready for making predictions
    
    Example:
        >>> predictor = load_predictor("best_model.h5")
        >>> predictions = predictor.predict(test_features)
    """
    return Predictor(model_path)
