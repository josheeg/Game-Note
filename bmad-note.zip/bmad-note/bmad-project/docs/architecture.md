# Architecture Document

## System Overview

The BMAD Modular CLI is a Python-based command-line application that orchestrates three distinct technical domains: Blender 3D generation, FreeCAD parametric modeling, and deep learning forecasting. The architecture follows a modular design pattern with clear separation of concerns between CLI, CAD operations, and ML functionality.

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        BMAD CLI Application                  │
│  ┌─────────────────────────────────────────────────────┐    │
│  │                 src/cli/main.py                      │    │
│  │              (Typer-based CLI entrypoint)            │    │
│  └─────────────────────────────────────────────────────┘    │
│                       │                                      │
│        ┌──────────────┼──────────────┐                      │
│        ▼              ▼              ▼                       │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐       │
│  │   Blender   │ │  FreeCAD    │ │   ML Forecasting│       │
│  │   Commands  │ │   Commands  │ │     Command     │       │
│  └─────────────┘ └─────────────┘ └─────────────────┘       │
│        │              │              │                      │
│        ▼              ▼              ▼                       │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────────┐       │
│  │   Blender   │ │  FreeCAD    │ │   ML Models     │       │
│  │   Builder   │ │   Builder   │ │   (Keras/Tuner) │       │
│  └─────────────┘ └─────────────┘ └─────────────────┘       │
└─────────────────────────────────────────────────────────────┘
```

## 1. Module Architecture

### 1.1 CLI Module (`src/cli/`)

The CLI module serves as the unified entry point for all operations.

#### Components

| File | Responsibility | Dependencies |
|------|----------------|--------------|
| `main.py` | CLI entrypoint, subcommand routing | Typer |
| `commands/blender_cmd.py` | Blender command orchestration | subprocess, bpy |
| `commands/freecad_cmd.py` | FreeCAD command orchestration | subprocess, freecad |
| `commands/forecast_cmd.py` | ML training/predict orchestration | Keras, NumPy |

#### Architecture Decision Records (ADRs)

**ADR-1: Typer over Click for CLI Framework**

```json
{
  "decision": "Use Typer instead of Click",
  "status": "Accepted",
  "context": "Typer provides better type hints integration and cleaner API surface. It generates nice help text automatically from function signatures.",
  "consequence": "Improved developer experience with type hints, automatic docstring generation from type annotations"
}
```

**ADR-2: Subprocess-based External Tool Invocation**

```json
{
  "decision": "Invoke Blender and FreeCAD via subprocess rather than embedding Python interpreters",
  "status": "Accepted", 
  "context": "Embedding CAD tool Python interpreters creates dependency conflicts. Subprocess calls allow each tool to use its own installation while maintaining clean separation.",
  "consequence": "Need to pass all arguments as command-line strings; cannot access external tool global state directly"
}
```

### 1.2 CAD Module (`src/cad/`)

The CAD module provides domain-specific 3D modeling functionality.

#### Blender Subsystem (`src/cad/blender/`)

**Scene Builder Architecture:**

```python
# Pseudo-code structure
class SceneBuilder:
    """Blender scene orchestration using subprocess calls."""
    
    def __init__(self, blender_path: str):
        self.blender_exe = blender_path  # System Blender installation
    
    def generate_scene(
        self,
        scene_name: str,
        resolution: tuple[int, int],
        lighting: str,
        **kwargs
    ) -> Path:
        """Generate a Blender scene and return output path."""
    
    def export_scene(
        self,
        scene_name: str,
        format: Literal["obj", "fbx", "gltf"],
        output_path: Path | None = None
    ) -> Path:
        """Export Blender scene in specified format."""
```

**Key Design Decisions:**

1. **Subprocess Wrapper Pattern**: Rather than using `bpy` Python API directly (which requires embedded Blender), we use subprocess calls to invoke Blender's built-in Python interpreter:

   ```bash
   blender -b --python script.py arguments...
   ```

2. **State Isolation**: Each operation runs in Blender's background mode (`-b` flag) to prevent GUI interference and allow headless execution.

3. **Error Propagation**: All subprocess errors are captured, logged with rich formatting, and propagated as CLI exceptions.

#### FreeCAD Subsystem (`src/cad/freecad/`)

**Model Builder Architecture:**

```python
class ModelBuilder:
    """FreeCAD model generation via Python scripting."""
    
    def __init__(self, freecad_exe: str | None = None):
        self.freecad_path = freecad_exe  # Auto-detect if not specified
    
    def generate_part(
        self,
        model_name: str,
        operation_type: Literal["extrude", "loft", "sweep"],
        **parameters
    ) -> Path:
        """Generate parametric part and return mesh file."""
    
    def export_model(
        self,
        model_name: str,
        format: Literal["step", "iges", "stl"],
        output_path: Path | None = None
    ) -> Path:
        """Export FreeCAD model in CAD interchange format."""
```

**Key Design Decisions:**

1. **Feature Tree Preservation**: When possible, we preserve the construction history for editability by using `--export-all-versions` flag.

2. **Kernel Abstraction**: The code abstracts over OCCT (Open CASCADE Technology) kernel operations through FreeCAD's Python API.

3. **Unit System Handling**: All geometric operations use millimeters as default unit, configurable via `config.yaml`.

### 1.3 ML Module (`src/ml/`)

The ML module provides deep learning time-series forecasting capabilities.

#### Components

| File | Responsibility | Key Classes |
|------|----------------|-------------|
| `model.py` | NN architecture definition | `ForecastingModel`, `LSTMModel` |
| `tuner.py` | Hyperparameter optimization | `HyperparameterTuner` |
| `dataset.py` | Data loading/preprocessing | `TimeSeriesDataset`, `Normalizer` |
| `predict.py` | Inference interface | `Predictor` |

**ML Architecture Pattern:**

```python
# Model architecture (src/ml/model.py)
class ForecastingModel(tf.keras.Model):
    """Base forecasting model with configurable layers."""
    
    def __init__(
        self,
        input_dim: int,
        hidden_dims: list[int],
        use_lstm: bool = False,
        **kwargs
    ):
        # Architecture: Input -> [Dense/LSTM] -> Dropout -> Dense -> Output
    
    def call(self, inputs):
        # Forward pass implementation
```

**Tuner Integration (src/ml/tuner.py):**

```python
class HyperparameterTuner(KTuner):
    """Keras Tuner wrapper for forecasting model optimization."""
    
    def __init__(self, hyperparams: dict[str, Any]):
        self.search_space = {
            "hidden_dims": kt.IntParameter(16, 256),
            "learning_rate": kt.FloatParameter(0.0001, 0.1),
            "batch_size": kt.IntParameter(16, 64),
            ...
        }
    
    def run_search(self, max_epochs: int = 10) -> dict:
        """Run hyperparameter search and return best config."""
```

**Dataset Architecture (src/ml/dataset.py):**

```python
class TimeSeriesDataset:
    """Time-series data loading with normalization."""
    
    def __init__(self, csv_path: Path, split_ratio: float = 0.8):
        # Load CSV, parse timestamps, extract features
    
    def train_test_split(self) -> tuple[Path, Path]:
        """Split data chronologically."""
```

### 1.4 Configuration System

**Configuration File Format (YAML):**

```yaml
# config.yaml structure
blender:
  resolution: [1920, 1080]
  lighting: studio
  materials: true
freecad:
  operation: extrude
  depth: 50
ml:
  architecture: mlp
  hidden_layers: [64, 32]
  epochs: 100
```

**Configuration Loading (src/cli/main.py):**

```python
def load_config(config_path: Path | None) -> dict[str, Any]:
    """Load configuration from YAML file or environment variables."""
    if config_path is None:
        return {}
    
    with open(config_path) as f:
        config = yaml.safe_load(f)
    
    # Merge with environment variables
    for key, value in os.environ.items():
        if key.startswith("BMAD_"):
            section = key[5:].lower()
            if section not in config:
                config[section] = {}
            config[section][key[5:].lower()] = value
    
    return config
```

## 2. Data Flow Architecture

### 2.1 Blender Module Data Flow

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   CLI       │────▶│  Blender Cmd     │────▶│  Scene Builder  │
│   Command   │     │  Orchestrator    │     │  (Subprocess)   │
└─────────────┘     └──────────────────┘     └─────────────────┘
                                               │
                                               ▼
                                    ┌─────────────────────────┐
                                    │  Blender Python API     │
                                    │  (Embedded interpreter) │
                                    └─────────────────────────┘
                                               │
                                               ▼
                                    ┌─────────────────────────┐
                                    │  Export to OBJ/FBX/GLTF │
                                    └─────────────────────────┘
```

### 2.2 FreeCAD Module Data Flow

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   CLI       │────▶│  FreeCAD Cmd     │────▶│  Model Builder  │
│   Command   │     │  Orchestrator    │     │  (Subprocess)   │
└─────────────┘     └──────────────────┘     └─────────────────┘
                                               │
                                               ▼
                                    ┌─────────────────────────┐
                                    │  FreeCAD Python API     │
                                    │  (Embedded interpreter) │
                                    └─────────────────────────┘
                                               │
                                               ▼
                                    ┌─────────────────────────┐
                                    │  Export STEP/IGES/STL  │
                                    └─────────────────────────┘
```

### 2.3 ML Module Data Flow

```
┌─────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   CLI       │────▶│  Forecast Cmd    │────▶│   Dataset       │
│   Command   │     │  Orchestrator    │     │  Loader         │
└─────────────┘     └──────────────────┘     └─────────────────┘
                                               │
                                               ▼
                                    ┌─────────────────────────┐
                                    │  Preprocessing & Split   │
                                    └─────────────────────────┘
                                               │
                                               ▼
                    ┌─────────────────────────────────────────┐
                    │              Model                       │
                    │           (Keras/Tuner)                  │
                    └─────────────────────────────────────────┘
                                               │
                                               ▼
                                    ┌─────────────────────────┐
                                    │  Evaluate/Predict        │
                                    └─────────────────────────┘
```

## 3. Interface Contracts

### 3.1 CLI Subcommand Interface

**Interface Signature:**

```python
@ typer.command()
def generate_blender(
    scene_name: str,
    resolution: tuple[int, int] = (1920, 1080),
    lighting: Literal["studio", "three_point", "ambient"] = "studio",
    config_path: Path | None = typer.Option(None, "--config", "-c"),
) -> Path: ...
```

**Interface Contract:**

| Parameter | Type | Description | Required |
|-----------|------|-------------|----------|
| `scene_name` | str | Unique identifier for the scene | Yes |
| `resolution` | tuple[int, int] | Target resolution (width, height) | No (default: 1920x1080) |
| `lighting` | str | Lighting preset name | No (default: "studio") |
| `config_path` | Path | Optional YAML config file | No |

**Return Type:** `Path` - Path to generated scene file

**Exit Codes:**

- `0`: Success
- `1`: General error
- `2`: Invalid arguments
- `3`: Dependency not found (Blender/FreeCAD missing)

### 3.2 ML Training Interface

```python
@ typer.command()
def train(
    dataset_path: Path,
    epochs: int = 100,
    batch_size: int = 32,
    split_ratio: float = 0.8,
    model_path: Path | None = typer.Option(None, "--output"),
) -> ModelCheckpoint: ...
```

**Interface Contract:**

| Parameter | Type | Description | Required |
|-----------|------|-------------|----------|
| `dataset_path` | Path | CSV file with time-series data | Yes |
| `epochs` | int | Training epochs | No (default: 100) |
| `batch_size` | int | Training batch size | No (default: 32) |
| `split_ratio` | float | Train/test split ratio | No (default: 0.8) |
| `model_path` | Path | Output model file path | No |

**Return Type:** `ModelCheckpoint` - Path to saved trained model

## 4. Error Handling Strategy

### 4.1 Error Classification

```python
class BMADError(Exception):
    """Base exception for all BMAD CLI errors."""
    pass

class DependencyNotFoundError(BMADError):
    """Raised when Blender/FreeCAD not found in PATH"""
    pass

class ConfigurationError(BMADError):
    """Raised when configuration is invalid"""
    pass

class DataProcessingError(BMADError):
    """Raised when data loading/preprocessing fails"""
    pass
```

### 4.2 Error Handling Pattern

```python
def safe_blender_execution(
    command: str,
    args: list[str],
    output_path: Path | None = None
) -> Path:
    """Execute Blender command with comprehensive error handling."""
    
    try:
        # Validate Blender installation
        validate_blender_installation()
        
        # Execute command
        result = subprocess.run(
            [blender_exe, "-b", "--python", script],
            capture_output=True,
            text=True,
            timeout=60  # NFR-1.1: Complete within 60s
        )
        
        if result.returncode != 0:
            raise BlenderError(
                f"Blender execution failed with code {result.returncode}. "
                f"Stderr: {result.stderr}"
            )
        
        return output_path if output_path else Path("output.scene")
    
    except FileNotFoundError:
        raise DependencyNotFoundError(
            "Blender not found in PATH. Please install Blender and add to PATH."
        )
    
    except subprocess.TimeoutExpired:
        raise RuntimeError(
            f"Blender execution timed out after 60 seconds. "
            "Consider reducing scene complexity or increasing timeout."
        )
```

## 5. Testing Architecture

### 5.1 Test Strategy Pyramid

```
                    ┌──────────────┐
                    │ Integration  │  (20% of tests)
                    │ Tests        │  CLI + subprocess interactions
                    └──────────────┘
                  ┌────────────────┐
                  │   Unit Tests   │  (50% of tests)
                  │ Pure logic     │  Module functions without external deps
                  └────────────────┘
                ┌──────────────────┐
                │  Mock Tests      │  (30% of tests)
                │ Subprocess mocks │  Test isolation and speed
                └──────────────────┘
```

### 5.2 Test Coverage Targets

| Module | Target Coverage | Description |
|--------|-----------------|-------------|
| CLI parsing | 95% | All subcommand arguments |
| Blender orchestration | 80% | Command construction, error handling |
| FreeCAD orchestration | 80% | Command construction, error handling |
| ML model architecture | 85% | All layer configurations |
| Dataset utilities | 90% | Loading, splitting, normalization |
| Tuner integration | 70% | Search space definition |

## 6. Security Considerations

### 6.1 Input Validation

```python
def validate_scene_name(scene_name: str) -> str:
    """Validate scene name against whitelist."""
    
    # Prevent path traversal and reserved names
    invalid_patterns = ["../", "..\\", "C:", "/etc/"]
    for pattern in invalid_patterns:
        if pattern in scene_name:
            raise ValueError(f"Invalid characters in scene name: {scene_name}")
    
    return scene_name.lower()  # Normalize to lowercase
```

### 6.2 Path Sanitization

```python
def sanitize_path(user_path: str) -> Path:
    """Sanitize user-provided file paths."""
    
    path = Path(user_path).expanduser().resolve()
    
    # Prevent directory traversal
    if ".." in str(path):
        raise ValueError("Path traversal not allowed")
    
    return path
```

## 7. Performance Optimization

### 7.1 Subprocess Pooling

For parallel Blender/FreeCAD operations:

```python
from concurrent.futures import ProcessPoolExecutor, as_completed

def process_scenes_parallel(scene_configs: list[dict]) -> list[tuple[str, Path]]:
    """Process multiple scenes in parallel using subprocess pool."""
    
    def process_single_scene(config: dict) -> tuple[str, Path]:
        scene_builder = SceneBuilder(config["blender_path"])
        return config["name"], scene_builder.generate_scene(**config)
    
    with ProcessPoolExecutor(max_workers=os.cpu_count()) as executor:
        futures = {
            executor.submit(process_single_scene, config): config["name"]
            for config in scene_configs
        }
        
        results = []
        for future in as_completed(futures):
            try:
                name, path = future.result(timeout=60)  # NFR-1.1
                results.append((name, path))
            except Exception as e:
                logger.error(f"Failed to process {future.key}: {e}")
    
    return results
```

### 7.2 ML Training Optimization

- Use `tf.data` API for efficient data loading
- Enable mixed precision training for GPU acceleration
- Implement model parallelism for large datasets

## 8. Future Extensibility Points

The architecture supports adding:

1. **Additional CAD Tools**: Unity, Unreal, or game engines via subprocess
2. **New ML Frameworks**: PyTorch, JAX (drop-in replacement)
3. **GUI Mode**: Headless flag removal for interactive Blender/FreeCAD use
4. **Cloud Deployment**: Docker containerization with tool images

## 9. Appendix A: Technology Stack

| Component | Technology | Version | Rationale |
|-----------|------------|---------|-----------|
| CLI Framework | Typer | ≥0.9.0 | Type hints integration, auto help text |
| Python API Wrapper | bpy-py | <0.4.0 | Blender 3.x compatibility |
| CAD Tool | Blender | 3.x | Industry standard 3D toolkit |
| CAD Tool | FreeCAD | 0.19+ / 1.x | Open-source parametric modeling |
| ML Framework | TensorFlow | ≥2.15.0 | Production-grade deep learning |
| ML API | Keras | ≥3.0.0 | High-level NN API |
| Hyperparameter Tuning | Keras Tuner | ≥1.3.0 | Integrated with Keras workflow |

## 10. Appendix B: File Dependencies Map

```
bmad-project/
├── pyproject.toml → Defines all dependencies and tools
├── README.md → User-facing documentation
└── src/
    ├── cli/
    │   ├── main.py                              # Typer app initialization
    │   └── commands/
    │       ├── blender_cmd.py                    # Blender subcommand logic
    │       ├── freecad_cmd.py                    # FreeCAD subcommand logic
    │       └── forecast_cmd.py                    # ML subcommand logic
    ├── cad/
    │   ├── blender/
    │   │   ├── scene_builder.py                  # Blender BPY orchestration
    │   │   └── export_utils.py                    # OBJ/FBX/GLTF export
    │   └── freecad/
    │       ├── model_builder.py                   # FreeCAD modeling logic
    │       └── export_utils.py                    # STEP/IGES/STL export
    └── ml/
        ├── model.py                              # NN architecture
        ├── tuner.py                              # Hyperparameter tuning
        ├── dataset.py                            # Data loading/preprocessing
        └── predict.py                            # Inference interface

└── tests/
    ├── test_cli.py                               # CLI integration tests
    ├── test_blender.py                           # Blender module tests
    ├── test_freecad.py                           # FreeCAD module tests
    └── test_ml.py                                # ML module tests
```

---

*Document Status: Draft*  
*Last Updated: 2024-09-17*  
*Next Review: After initial implementation*