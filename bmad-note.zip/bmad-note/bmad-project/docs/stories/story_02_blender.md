# Epic: Blender Module Implementation

## Epic ID: EPIC-BLEN-01

### Epic Description
Implement Blender 3D scene generation and export functionality using subprocess invocation to Blender's embedded Python interpreter.

### User Stories

#### Story 2.1: Blender Installation Validation
**User Story:** US-BLEN-01

> **As a** user,  
> **I want** validation of Blender installation,  
> **So that** I get clear error messages if Blender is not available.

**Acceptance Criteria:**
- [ ] Check Blender executable in PATH before operations
- [ ] Raise DependencyNotFoundError with helpful message if missing
- [ ] Validate Blender version compatibility (3.x required)
- [ ] Exit code 3 for dependency errors

**Technical Notes:**
```python
def validate_blender_installation(blender_path: str | None = None) -> str:
    """
    Validate Blender installation and return executable path.
    
    Args:
        blender_path: Optional explicit Blender path; auto-detect if None
    
    Returns:
        Full path to Blender executable
    
    Raises:
        DependencyNotFoundError: If Blender not found in PATH
    """
```

#### Story 2.2: Scene Generation
**User Story:** US-BLEN-02

> **As a** 3D artist,  
> **I want** to generate scenes programmatically,  
> **So that** I can automate repetitive rendering tasks.

**Acceptance Criteria:**
- [ ] Generate basic geometry (cube, sphere, cylinder)
- [ ] Configure scene resolution (width × height)
- [ ] Apply lighting preset (studio, three-point, ambient)
- [ ] Export scene file with proper naming convention
- [ ] Return path to generated scene

**Technical Notes:**
- Use Blender's `-b` flag for background mode (headless execution)
- Create Python script dynamically based on command parameters
- Execute via subprocess: `blender -b --python script.py arguments...`

#### Story 2.3: Scene Export
**User Story:** US-BLEN-03

> **As a** user,  
> **I want** to export scenes in multiple formats,  
> **So that** I can use them with different applications.

**Acceptance Criteria:**
- [ ] Export to OBJ format with UV mapping
- [ ] Export to FBX with animation support
- [ ] Export to GLTF/GLB for web compatibility
- [ ] Preserve material and texture assignments during export

**Technical Notes:**
```python
def export_scene(
    scene_name: str,
    format: Literal["obj", "fbx", "gltf"],
    output_path: Path | None = None,
) -> Path:
    """Export Blender scene in specified format."""
```

---

## Epic Acceptance Criteria

| ID | Criterion | Status |
|----|-----------|--------|
| EPIC-AC-1 | Blender validation works correctly | ⏳ |
| EPIC-AC-2 | Scene generation completes within 60s | ⏳ |
| EPIC-AC-3 | All export formats produce valid files | ⏳ |

## Technical Specifications

### File Structure
```
src/cad/blender/
├── __init__.py
└── scene_builder.py        # Core Blender orchestration
```

### Component Interfaces

**Scene Builder (`scene_builder.py`):**

```python
from pathlib import Path
from typing import Literal, tuple

class SceneBuilder:
    """Blender scene orchestration using subprocess calls."""
    
    def __init__(self, blender_path: str):
        """Initialize with Blender executable path.
        
        Args:
            blender_path: Full path to Blender executable (auto-detect if default)
        """
        self.blender_exe = blender_path or self._detect_blender()
    
    def _detect_blender(self) -> str:
        """Auto-detect Blender in common installation locations."""
        import os
        common_paths = [
            r"C:\Program Files\Blender Foundation\Blender",  # Windows
            "/usr/bin/blender",                              # Linux
            "/usr/local/bin/blender",                        # Mac
        ]
        for path in common_paths:
            if os.path.exists(path):
                return path
        return ""
    
    def generate_scene(
        self,
        scene_name: str,
        resolution: tuple[int, int] = (1920, 1080),
        lighting: Literal["studio", "three_point", "ambient"] = "studio",
    ) -> Path:
        """Generate a Blender scene and return output path.
        
        Args:
            scene_name: Unique identifier for the scene
            resolution: Target resolution (width, height)
            lighting: Lighting preset name
        
        Returns:
            Path to generated scene file
        """
        # Implementation uses subprocess with dynamic Python script
        pass
    
    def export_scene(
        self,
        scene_name: str,
        format: Literal["obj", "fbx", "gltf"],
        output_path: Path | None = None,
    ) -> Path:
        """Export Blender scene in specified format.
        
        Args:
            scene_name: Scene identifier
            format: Export format (obj, fbx, gltf)
            output_path: Optional output path; defaults to current directory
        
        Returns:
            Path to exported file
        """
        # Implementation uses bpy.ops.export_... commands
        pass
```

### Subprocess Execution Pattern

```python
import subprocess

def _execute_blender_script(self, script_content: str, arguments: list[str]) -> subprocess.CompletedProcess:
    """Execute Blender with Python script.
    
    Args:
        script_content: Python code to run in Blender
        arguments: Additional command-line arguments
    
    Returns:
        CompletedProcess result
    """
    process = subprocess.run(
        [self.blender_exe, "-b", "--python-execute", "-", *arguments],
        input=script_content.encode("utf-8"),
        capture_output=True,
        text=True,
        timeout=60  # NFR-1.1: Complete within 60s
    )
    return process
```

## Test Plan

| Test ID | Description | Expected Result |
|---------|-------------|-----------------|
| BLEN-TC-01 | Validate Blender installation detection | Returns correct path or raises DependencyNotFoundError |
| BLEN-TC-02 | Generate simple cube scene | Creates .blend file, exit code 0 |
| BLEN-TC-03 | Export to OBJ format | Produces valid OBJ with vertex/color/normal data |
| BLEN-TC-04 | Handle Blender execution timeout | Raises TimeoutError after 60s |

## Dependencies

| Dependency | Type | Source | Version |
|------------|------|--------|---------|
| subprocess | Built-in | Python stdlib | - |
| bpy-py | Optional wrapper | pip | <0.4.0 |

## References

- Blender Python API Documentation: https://docs.blender.org/api/current/bpy.html
- PRD Section: FR-2 (Blender Module)
- Architecture Document Section 1.2 CAD Module → Blender Subsystem

---

*Story Status: In Progress*  
*Last Updated: 2024-09-17*