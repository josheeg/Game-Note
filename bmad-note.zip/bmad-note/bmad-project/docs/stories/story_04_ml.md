# Epic: ML Forecasting Module Implementation

## Epic ID: EPIC-ML-01

### Epic Description
Implement deep learning time-series forecasting using TensorFlow/Keras with Keras Tuner hyperparameter optimization.

### User Stories

#### Story 4.1: Data Loading and Preprocessing
**User Story:** US-ML-01

> **As a** data scientist,  
> **I want** to load and preprocess CSV time-series data,  
> **So that** I can train forecasting models without manual preparation.

**Acceptance Criteria:**
- [ ] Parse CSV with timestamp column as index
- [ ] Normalize features using MinMaxScaler or StandardScaler
- [ ] Split data chronologically (not randomly)
- [ ] Handle missing values with forward-fill interpolation
- [ ] Create train/validation/test splits based on time

#### Story 4.2: Neural Network Architecture
**User Story:** US-ML-02

> **As a** developer,  
> **I want** to configure model architecture via parameters,  
> **So that** I can experiment with different network topologies.

**Acceptance Criteria:**
- [ ] Support MLP (Multi-Layer Perceptron) base architecture
- [ ] Support LSTM for sequential data patterns
- [ ] Configurable hidden layer dimensions
- [ ] Configurable activation functions (relu, tanh, sigmoid)
- [ ] Dropout layers for regularization

#### Story 4.3: Hyperparameter Optimization
**User Story:** US-ML-03

> **As a** researcher,  
> **I want** automated hyperparameter tuning with Keras Tuner,  
> **So that** I can find optimal model configuration efficiently.

**Acceptance Criteria:**
- [ ] Define search space for key parameters (layers, lr, batch_size)
- [ ] Implement HyperParameterTrial execution
- [ ] Track metrics across trials (mae, rmse, loss)
- [ ] Return best-performing configuration

#### Story 4.4: Model Training and Evaluation
**User Story:** US-ML-04

> **As a** practitioner,  
> **I want** to train models with early stopping and checkpointing,  
> **So that** I can prevent overfitting and save best weights.

**Acceptance Criteria:**
- [ ] Implement early stopping on validation loss
- [ ] Save model checkpoints at regular intervals
- [ ] Evaluate using MAE, RMSE, MAPE metrics
- [ ] Generate training history for visualization

#### Story 4.5: Model Inference and Export
**User Story:** US-ML-05

> **As a** user,  
> **I want** to make predictions on new data and export models,  
> **So that** I can deploy forecasts in production environments.

**Acceptance Criteria:**
- [ ] Load saved Keras model from HDF5 or SavedModel format
- [ ] Accept preprocessed input features for prediction
- [ ] Return predicted values with confidence intervals (optional)
- [ ] Export model weights and architecture to file

---

## Epic Acceptance Criteria

| ID | Criterion | Status |
|----|-----------|--------|
| EPIC-AC-1 | Data loading handles various CSV formats | ⏳ |
| EPIC-AC-2 | Model training completes within 5min for 10k samples | ⏳ |
| EPIC-AC-3 | All metrics (MAE, RMSE, MAPE) computed correctly | ⏳ |

## Technical Specifications

### File Structure
```
src/ml/
├── __init__.py
├── model.py                # Neural network architecture
├── tuner.py                # Keras Tuner integration
├── dataset.py              # Data loading/preprocessing
└── predict.py              # Inference interface
```

### Component Interfaces

**Dataset Loader (`dataset.py`):**

```python
import pandas as pd
from typing import Tuple, Literal
from sklearn.preprocessing import MinMaxScaler
import numpy as np

class TimeSeriesDataset:
    """Time-series data loading with normalization and splitting."""
    
    def __init__(
        self,
        csv_path: str,
        timestamp_column: str = "timestamp",
        target_columns: list[str] | None = None,
        split_ratio: float = 0.8,
    ):
        """Initialize dataset from CSV file.
        
        Args:
            csv_path: Path to CSV file with time-series data
            timestamp_column: Name of column containing timestamps
            target_columns: Columns to predict (None for all numeric)
            split_ratio: Train/test split ratio (default 0.8)
        """
        self.csv_path = csv_path
        self.df = self._load_csv()
        self.timestamp_col = timestamp_column
        self.target_cols = target_columns
    
    def _load_csv(self) -> pd.DataFrame:
        """Load CSV file and parse timestamp as index."""
        df = pd.read_csv(self.csv_path, parse_dates=[self.timestamp_col])
        df.set_index(self.timestamp_col, inplace=True)
        # Handle missing values with forward-fill
        df.fillna(method='ffill', inplace=True)
        return df
    
    def normalize_features(self) -> tuple[pd.DataFrame, MinMaxScaler]:
        """Normalize all numeric features.
        
        Returns:
            Tuple of (normalized dataframe, fitted scaler)
        """
        # Implementation with sklearn.preprocessing
        pass
    
    def train_test_split(self, time_gap: int = 0) -> Tuple[Tuple[str], Tuple[str]]:
        """Split data chronologically.
        
        Args:
            time_gap: Time gap between train and test to prevent look-ahead bias
        
        Returns:
            Tuple of (train_path, test_path)
        """
        pass
```

**Model Architecture (`model.py`):**

```python
import tensorflow as tf
from tensorflow import keras
from typing import List, Literal, Optional
import numpy as np

class ForecastingModel(keras.Model):
    """Base forecasting model with configurable architecture."""
    
    def __init__(
        self,
        input_dim: int,
        hidden_dims: List[int],
        use_lstm: bool = False,
        lstm_units: int = 64,
        dropout_rate: float = 0.2,
        activation: Literal["relu", "tanh", "sigmoid"] = "relu",
    ):
        """Initialize model with specified architecture.
        
        Args:
            input_dim: Number of input features
            hidden_dims: List of hidden layer dimensions
            use_lstm: Whether to use LSTM layers instead of Dense
            lstm_units: Number of LSTM units (if use_lstm=True)
            dropout_rate: Dropout rate for regularization
            activation: Activation function type
        """
        super().__init__()
        
        self.input_dim = input_dim
        self.hidden_dims = hidden_dims
        self.use_lstm = use_lstm
        self.lstm_units = lstm_units
        self.dropout_rate = dropout_rate
        self.activation = activation
    
    def build(self, input_shape):
        """Build model architecture."""
        layers = [keras.Input(shape=input_shape)]
        
        # Add LSTM or Dense layers based on configuration
        if self.use_lstm:
            for units in self.hidden_dims:
                layers.append(keras.layers.LSTM(units, activation=self.activation))
        else:
            for units in self.hidden_dims:
                layers.append(keras.layers.Dense(units, activation=self.activation))
        
        # Add dropout layers
        for _ in range(len(self.hidden_dims)):
            layers.append(keras.layers.Dropout(self.dropout_rate))
        
        # Output layer
        layers.append(keras.layers.Dense(1))
        
        self.model = keras.Model(input_shape[0], layers[-1])
    
    def compile(self, optimizer: str = "adam", 
                loss: str = "mse", metrics: list[str] = None):
        """Compile model with specified configuration."""
        optimizer = keras.optimizers.Adam(learning_rate=0.001)
        loss = "mse"  # Mean Squared Error for regression
    
    def call(self, inputs):
        """Forward pass."""
        return self.model(inputs)
    
    def train_step(self, data):
        """Custom training step for logging."""
        x, y = data
        with tf.GradientTape() as tape:
            predictions = self(x)
            loss_value = loss(y, predictions)
        
        gradients = tape.gradient(loss, self.trainable_variables)
        optimizer.apply_gradients(zip(gradients, self trainable_variables))
        
        return {"loss": loss_value, "predictions": predictions}
```

**Hyperparameter Tuner (`tuner.py`):**

```python
import keras_tuner as kt
from typing import Any, Dict
import numpy as np

class HyperparameterTuner(kt.KTuner):
    """Keras Tuner wrapper for forecasting model optimization."""
    
    def __init__(self, hyperparams: dict[str, Any]):
        """Initialize tuner with search space definition.
        
        Args:
            hyperparams: Dictionary of hyperparameters and their ranges
        """
        super().__init__(kt.RandomSearch())
        self.search_space = hyperparams
    
    def build_model(self, hp, input_dim, use_lstm=False):
        """Build model given hyperparameter values."""
        hidden_dims = hp.Choice("hidden_dims", [16, 32, 64, 128])
        learning_rate = hp.Float("learning_rate", 0.0001, 0.1, sampling="log")
        dropout_rate = hp.Float("dropout_rate", 0.1, 0.5, sampling="linear")
        use_lstm_bool = hp.Choice("use_lstm", [True, False])
        
        model = ForecastingModel(
            input_dim=input_dim,
            hidden_dims=[hidden_dims] * 2,  # Two hidden layers
            use_lstm=use_lstm_bool,
            dropout_rate=dropout_rate,
            activation="relu",
        )
        
        model.compile(
            optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
            loss="mse",
            metrics=["mae"],
        )
        
        return model
    
    def objective(self, model):
        """Objective function for hyperparameter search."""
        # Train and evaluate model
        history = model.fit(
            train_data,
            validation_data=val_data,
            epochs=self.max_epochs,
            verbose=0,
        )
        
        val_loss = history.history["val_loss"][0]
        return val_loss
    
    def run_search(self, max_trials: int = 10) -> Dict[str, Any]:
        """Run hyperparameter search.
        
        Args:
            max_trials: Number of trials to execute
        
        Returns:
            Dictionary containing best model and configuration
        """
        # Execute search
        pass
```

**Inference Interface (`predict.py`):**

```python
import tensorflow as tf
from pathlib import Path
from typing import Optional, Tuple

class Predictor:
    """Model inference and prediction interface."""
    
    def __init__(self, model_path: str):
        """Initialize predictor with trained model.
        
        Args:
            model_path: Path to saved Keras model (HDF5 or SavedModel)
        """
        self.model = tf.keras.models.load_model(model_path)
    
    def predict(
        self,
        input_features: np.ndarray,
        time_steps: int = 1,
    ) -> Tuple[np.ndarray, Optional[np.ndarray]]:
        """Make predictions on input features.
        
        Args:
            input_features: Preprocessed input features (numpy array)
            time_steps: Number of future steps to predict
        
        Returns:
            Tuple of (predictions, confidence_intervals)
        """
        predictions = self.model.predict(input_features)
        return predictions
    
    def export(
        self,
        output_path: str,
        format: Literal["hdf5", "saved_model"] = "hdf5",
    ):
        """Export model to specified format.
        
        Args:
            output_path: Path to save exported model
            format: Export format (hdf5 or saved_model)
        """
        if format == "saved_model":
            self.model.save(output_path, save_format="saved_model")
        else:
            self.model.save(output_path)
```

### Training Pipeline Pattern

```python
def train_forecasting_model(
    dataset: TimeSeriesDataset,
    epochs: int = 100,
    batch_size: int = 32,
    early_stopping_patience: int = 5,
    use_tuner: bool = False,
) -> Path:
    """Complete training pipeline.
    
    Args:
        dataset: Preprocessed TimeSeriesDataset
        epochs: Maximum number of training epochs
        batch_size: Training batch size
        early_stopping_patience: Patience for early stopping
        use_tuner: Whether to use Keras Tuner for hyperparameter search
    
    Returns:
        Path to saved best model
    """
    # Implementation combines all ML components
    pass
```

## Test Plan

| Test ID | Description | Expected Result |
|---------|-------------|-----------------|
| ML-TC-01 | Load CSV data with timestamp column | Parses correctly, sets index |
| ML-TC-02 | Chronological split preserves time order | No look-ahead bias |
| ML-TC-03 | Train MLP model and evaluate | Converges within epochs, returns metrics |
| ML-TC-04 | Export model in HDF5 format | Loads correctly with `load_model()` |

## Dependencies

| Dependency | Type | Source | Version |
|------------|------|--------|---------|
| tensorflow | ML framework | pip | ≥2.15.0 |
| keras | NN API | pip | ≥3.0.0 |
| keras-tuner | Hyperparameter tuning | pip | ≥1.3.0 |
| numpy | Numerical computations | pip | ≥1.24.0 |
| scikit-learn | ML utilities | pip | ≥1.3.0 |

## References

- TensorFlow Documentation: https://www.tensorflow.org/
- Keras Tuner Documentation: https://keras-tuner.dev/
- PRD Section: FR-4 (ML Forecasting Module)
- Architecture Document Section 1.3 ML Module

---

*Story Status: In Progress*  
*Last Updated: 2024-09-17*