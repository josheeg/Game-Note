# Epic: FreeCAD Module Implementation

## Epic ID: EPIC-FCAD-01

### Epic Description
Implement FreeCAD parametric modeling and export functionality using subprocess invocation to FreeCAD's embedded Python interpreter.

### User Stories

#### Story 3.1: FreeCAD Installation Validation
**User Story:** US-FCAD-01

> **As a** mechanical engineer,  
> **I want** validation of FreeCAD installation,  
> **So that** I get clear error messages if FreeCAD is not available.

**Acceptance Criteria:**
- [ ] Check FreeCAD executable in PATH before operations
- [ ] Raise DependencyNotFoundError with helpful message if missing
- [ ] Validate FreeCAD version compatibility (0.19+ or 1.x required)
- [ ] Exit code 3 for dependency errors

#### Story 3.2: Part Design Automation
**User Story:** US-FCAD-02

> **As a** designer,  
> **I want** to create parametric parts programmatically,  
> **So that** I can integrate CAD generation into my workflow.

**Acceptance Criteria:**
- [ ] Create primitive shapes (box, cylinder, sphere, cone)
- [ ] Apply feature operations (extrude, loft, sweep, revolution)
- [ ] Manage construction history and feature tree
- [ ] Apply materials and textures to objects

#### Story 3.3: CAD Format Export
**User Story:** US-FCAD-03

> **As a** user,  
> **I want** to export models in CAD formats,  
> **So that** I can share with other CAD software.

**Acceptance Criteria:**
- [ ] Export to STEP (ISO 10303) for exchange
- [ ] Export to IGES for legacy compatibility
- [ ] Export to STL for 3D printing
- [ ] Preserve geometry and topology during export

---

## Epic Acceptance Criteria

| ID | Criterion | Status |
|----|-----------|--------|
| EPIC-AC-1 | FreeCAD validation works correctly | ⏳ |
| EPIC-AC-2 | Part generation completes within 45s | ⏳ |
| EPIC-AC-3 | All export formats produce valid CAD files | ⏳ |

## Technical Specifications

### File Structure
```
src/cad/freecad/
├── __init__.py
└── model_builder.py        # Core FreeCAD orchestration
```

### Component Interfaces

**Model Builder (`model_builder.py`):**

```python
from pathlib import Path
from typing import Literal, Any

class ModelBuilder:
    """FreeCAD model generation via Python scripting."""
    
    def __init__(self, freecad_path: str | None = None):
        """Initialize with FreeCAD executable path.
        
        Args:
            freecad_path: Full path to FreeCAD executable (auto-detect if None)
        """
        self.freecad_exe = freecad_path or self._detect_freecad()
    
    def _detect_freecad(self) -> str:
        """Auto-detect FreeCAD in common installation locations."""
        import os
        common_paths = [
            r"C:\Program Files\FreeCAD",              # Windows
            "/usr/bin/freecad",                       # Linux
            "/opt/freecad/bin/freecad",               # Debian/Ubuntu
        ]
        for path in common_paths:
            if os.path.exists(path):
                return path
        return ""
    
    def generate_part(
        self,
        model_name: str,
        operation_type: Literal["extrude", "loft", "sweep", "revolution"],
        **parameters: Any,
    ) -> Path:
        """Generate parametric part and return mesh file.
        
        Args:
            model_name: Unique identifier for the model
            operation_type: Feature operation to apply
            **parameters: Operation-specific parameters
        
        Returns:
            Path to generated mesh file
        """
        # Implementation uses subprocess with FreeCAD Python script
        pass
    
    def export_model(
        self,
        model_name: str,
        format: Literal["step", "iges", "stl"],
        output_path: Path | None = None,
    ) -> Path:
        """Export FreeCAD model in CAD interchange format.
        
        Args:
            model_name: Model identifier
            format: Export format (step, iges, stl)
            output_path: Optional output path
        
        Returns:
            Path to exported file
        """
        # Implementation uses FreeCAD export functionality
        pass
    
    def create_primitive(
        self,
        primitive_type: Literal["box", "cylinder", "sphere", "cone"],
        dimensions: list[float],
    ):
        """Create a primitive shape.
        
        Args:
            primitive_type: Type of primitive to create
            dimensions: Shape-specific dimension list
        
        Returns:
            Part object from FreeCAD
        """
        # Implementation creates primitives via FreeCAD API
        pass
    
    def apply_feature_operation(
        self,
        base_object,
        operation: Literal["extrude", "loft", "sweep", "revolution"],
        **params: Any,
    ):
        """Apply a feature operation to an object.
        
        Args:
            base_object: Object to apply operation to
            operation: Feature operation type
            **params: Operation-specific parameters
        
        Returns:
            Resulting object after operation
        """
        # Implementation applies feature tree operations
        pass
```

### Subprocess Execution Pattern

```python
import subprocess
from typing import Any, Dict

def _execute_freecad_script(self, script_content: str, arguments: list[str]) -> subprocess.CompletedProcess:
    """Execute FreeCAD with Python script.
    
    Args:
        script_content: Python code to run in FreeCAD
        arguments: Additional command-line arguments
    
    Returns:
        CompletedProcess result
    """
    process = subprocess.run(
        [self.freecad_exe, "--console", "-c", f"import sys; sys.stdin = __builtins__['stdin']", 
         *arguments],
        input=script_content.encode("utf-8"),
        capture_output=True,
        text=True,
        timeout=45  # NFR-1.2: Complete within 45s
    )
    return process
```

### Feature Tree Management Pattern

```python
from freecad import Part, Draft, Mesh  # FreeCAD Python modules

def _build_feature_tree(self, model_name: str) -> Dict[str, Any]:
    """Build feature tree structure for parametric modeling."""
    
    feature_tree = {
        "base": None,              # Starting primitive or import
        "operations": [],          # List of operations in order
        "constraints": [],         # Geometric constraints
    }
    
    return feature_tree
```

## Test Plan

| Test ID | Description | Expected Result |
|---------|-------------|-----------------|
| FCAD-TC-01 | Validate FreeCAD installation detection | Returns correct path or raises DependencyNotFoundError |
| FCAD-TC-02 | Generate box primitive | Creates .FCStd file with single Part object |
| FCAD-TC-03 | Apply extrusion operation | Creates solid from 2D sketch |
| FCAD-TC-04 | Export to STEP format | Produces valid STEP AP203/214 file |

## Dependencies

| Dependency | Type | Source | Version |
|------------|------|--------|---------|
| subprocess | Built-in | Python stdlib | - |
| FreeCAD Python API | Optional wrapper | System installation | 0.19+ / 1.x |

## References

- FreeCAD Documentation: https://docs.freecad.org/
- FreeCAD Python API: https://github.com/FreeCAD/pythonOCC
- PRD Section: FR-3 (FreeCAD Module)
- Architecture Document Section 1.2 CAD Module → FreeCAD Subsystem

---

*Story Status: In Progress*  
*Last Updated: 2024-09-17*