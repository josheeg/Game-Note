# Epic: CLI Interface & Project Setup

## Epic ID: EPIC-CLI-01

### Epic Description
Establish a unified command-line interface that serves as the single entry point for all BMAD operations, with proper subcommand routing and configuration support.

### User Stories

#### Story 1.1: CLI Entry Point
**User Story:** US-CLI-01

> **As a** developer,  
> **I want** a unified CLI with Typer framework,  
> **So that** I can execute all BMAD operations from one entry point.

**Acceptance Criteria:**
- [ ] Typer app initializes correctly on `bmad-cli` command
- [ ] All subcommands accessible via help system
- [ ] Exit code 0 on success, non-zero on failure
- [ ] Type hints present on all functions

**Technical Notes:**
- Use Typer's `app = typer.Typer()` pattern
- Implement subcommands as grouped commands with `@app.command()` decorators
- Add `--help` support automatically generated from type signatures

**Dependencies:**
- `typer>=0.9.0` (defined in pyproject.toml)

#### Story 1.2: Configuration Loading
**User Story:** US-CLI-02

> **As a** user,  
> **I want** to load YAML configuration files,  
> **So that** I can customize operations without command-line clutter.

**Acceptance Criteria:**
- [ ] Accept `--config` flag for YAML file path
- [ ] Parse and merge YAML config with environment variables
- [ ] Validate configuration structure before use
- [ ] Provide helpful errors for invalid YAML syntax

**Technical Notes:**
- Use PyYAML for parsing
- Support nested dictionary structures
- Implement environment variable interpolation for `BMAD_*` prefixed vars

---

## Epic Acceptance Criteria

| ID | Criterion | Status |
|----|-----------|--------|
| EPIC-AC-1 | All subcommands accessible from CLI root | ⏳ |
| EPIC-AC-2 | Configuration files load and merge correctly | ⏳ |
| EPIC-AC-3 | Error messages are clear and actionable | ⏳ |

## Technical Specifications

### File Structure
```
src/cli/
├── main.py              # Typer app initialization
└── commands/
    ├── __init__.py
    ├── blender_cmd.py   # Blender subcommand
    ├── freecad_cmd.py   # FreeCAD subcommand
    └── forecast_cmd.py   # ML subcommand
```

### Component Interfaces

**CLI Entry Point (`main.py`):**

```python
from typer import Typer

app = Typer(
    name="bmad-cli",
    help="Modular CLI for 3D generation and ML forecasting",
    add_completion=False,
)

# Subcommand registration occurs here
```

**Subcommand Interface Contract:**

```python
def subcommand_function(
    name: str,  # Required parameter
    optional_param: str = typer.Option("default", "--param"),
    config_path: Path | None = typer.Option(None, "--config"),
) -> Path:
    """
    Subcommand function signature.
    
    Args:
        name: Primary identifier for operation
        optional_param: Optional parameter with default
        config_path: Optional YAML configuration file
    
    Returns:
        Path to output artifact
    """
```

## Test Plan

| Test ID | Description | Expected Result |
|---------|-------------|-----------------|
| CLI-TC-01 | Verify `bmad-cli --help` displays all subcommands | Shows grouped help |
| CLI-TC-02 | Subcommand without required parameter exits with error | Non-zero exit code, helpful message |
| CLI-TC-03 | Invalid config file raises appropriate exception | ConfigurationError raised |

## References

- [Typer Documentation](https://typer.tiangolo.com/)
- PRD Section: FR-1 (CLI Interface Management)
