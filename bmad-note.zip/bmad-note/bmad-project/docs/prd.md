# Product Requirements Document (PRD)

## Version History

| Version | Date       | Author      | Changes                        |
|---------|------------|-------------|--------------------------------|
| 1.0.0   | 2024-09-17 | BMAD Team   | Initial PRD creation           |

## 1. Executive Summary

The BMAD Modular CLI is a unified command-line application that integrates three distinct technical domains: Blender 3D asset generation, FreeCAD parametric modeling, and deep learning time-series forecasting. The application provides a single binary entry point with organized subcommands for each domain.

### Business Value

- **Unified Interface**: Single tool for multiple use cases reduces context switching
- **Modular Architecture**: Each domain can be developed and maintained independently
- **Extensibility**: Easy to add new CAD tools or ML frameworks in the future
- **Automation**: Scriptable workflows for repetitive 3D generation tasks

## 2. Functional Requirements

### FR-1: CLI Interface Management

| ID   | Requirement                                                                 | Priority | Status |
|------|-----------------------------------------------------------------------------|----------|--------|
| CLI-1 | Accept subcommands for each module (blender, freecad, forecast)            | MUST     | ✅      |
| CLI-2 | Provide comprehensive help text for all commands                            | MUST     | ✅      |
| CLI-3 | Exit with appropriate error codes (0=success, non-zero=failure)            | SHOULD   | ⏳      |
| CLI-4 | Parse command-line arguments and configuration files                        | MUST     | ✅      |

### FR-2: Blender Module

| ID         | Requirement                                                                                           | Priority | Status |
|------------|------------------------------------------------------------------------------------------------------|----------|--------|
| BLEN-1     | Generate 3D scenes using Blender Python API (bpy or subprocess)                                      | MUST     | ⏳      |
| BLEN-2     | Support parametric asset generation with configurable parameters                                     | MUST     | ⏳      |
| BLEN-3     | Create and configure scene lighting (studio, three-point, ambient)                                   | SHOULD   | ⏳      |
| BLEN-4     | Assign materials and textures to mesh objects                                                        | SHOULD   | ⏳      |
| BLEN-5     | Configure camera positions and focal lengths                                                         | SHOULD   | ⏳      |
| BLEN-6     | Export scenes in multiple formats (OBJ, FBX, GLTF)                                                   | MUST     | ⏳      |
| BLEN-7     | Validate Blender installation before attempting operations                                           | MUST     | ✅      |

### FR-3: FreeCAD Module

| ID         | Requirement                                                                                           | Priority | Status |
|------------|------------------------------------------------------------------------------------------------------|----------|--------|
| FCAD-1     | Generate parametric parts using FreeCAD Python scripting                                             | MUST     | ⏳      |
| FCAD-2     | Support primitive operations (extrude, loft, sweep, revolution)                                       | MUST     | ⏳      |
| FCAD-3     | Manage feature tree and construction history                                                         | SHOULD   | ⏳      |
| FCAD-4     | Create constraint-based assemblies                                                                   | SHOULD   | ⏳      |
| FCAD-5     | Export models in CAD formats (STEP, IGES, STL)                                                       | MUST     | ⏳      |
| FCAD-6     | Validate FreeCAD installation and Python interpreter before operations                               | MUST     | ✅      |

### FR-4: ML Forecasting Module

| ID         | Requirement                                                                                           | Priority | Status |
|------------|------------------------------------------------------------------------------------------------------|----------|--------|
| ML-1       | Load and preprocess time-series data with normalization                                              | MUST     | ⏳      |
| ML-2       | Split data into train/validation/test sets (configurable ratio)                                      | MUST     | ✅      |
| ML-3       | Build deep neural network architecture (MLP base, LSTM optional)                                     | MUST     | ⏳      |
| ML-4       | Implement Keras Tuner for hyperparameter optimization                                                | SHOULD   | ⏳      |
| ML-5       | Train models with early stopping and checkpointing                                                   | SHOULD   | ⏳      |
| ML-6       | Evaluate models using MAE, RMSE, MAPE metrics                                                        | MUST     | ⏳      |
| ML-7       | Export trained models in Keras HDF5 format                                                           | SHOULD   | ⏳      |
| ML-8       | Perform inference on new data points                                                                 | MUST     | ⏳      |

### FR-5: Configuration & Orchestration

| ID         | Requirement                                                                                           | Priority | Status |
|------------|------------------------------------------------------------------------------------------------------|----------|--------|
| CFG-1      | Support YAML configuration files for each module                                                     | SHOULD   | ⏳      |
| CFG-2      | Accept environment variables for sensitive parameters                                                | MUST     | ✅      |
| CFG-3      | Validate configuration before execution                                                              | MUST     | ⏳      |
| CFG-4      | Provide JSON output for programmatic consumption                                                     | SHOULD   | ⏳      |

## 3. Non-Functional Requirements

### NFR-1: Performance
- **NFR-1.1**: Blender commands complete within 60 seconds for standard scenes
- **NFR-1.2**: FreeCAD operations complete within 45 seconds for part designs
- **NFR-1.3**: ML training scales linearly with dataset size (≤5min for 10k samples)

### NFR-2: Reliability
- **NFR-2.1**: Handle missing dependencies gracefully with helpful error messages
- **NFR-2.2**: Rollback on failed subprocess execution (Blender/FreeCAD)
- **NFR-2.3**: Preserve intermediate artifacts for debugging

### NFR-3: Security
- **NFR-3.1**: Validate all command-line arguments against whitelist
- **NFR-3.2**: Sanitize file paths to prevent directory traversal attacks
- **NFR-3.3**: No hardcoded secrets or API keys in source code

### NFR-4: Maintainability
- **NFR-4.1**: Achieve ≥30% unit test coverage on core modules
- **NFR-4.2**: All public functions include docstrings with examples
- **NFR-4.3**: Use type hints throughout codebase (gradual adoption)
- **NFR-4.4**: Follow PEP 8 coding style and black formatting

### NFR-5: Compatibility
- **NFR-5.1**: Python 3.10, 3.11, or 3.12
- **NFR-5.2**: Blender 3.x (via subprocess invocation)
- **NFR-5.3**: FreeCAD 0.19+ or 1.x
- **NFR-5.4**: TensorFlow/Keras 2.15+

## 4. User Stories

### US-1: CLI Entry Point

> **As a** developer,  
> **I want** a unified CLI interface,  
> **So that** I can manage multiple tools without switching contexts.

```bash
bmad-cli --help
# Shows all available subcommands and options
```

### US-2: Blender Scene Generation

> **As a** 3D artist,  
> **I want** to generate scenes programmatically,  
> **So that** I can automate repetitive rendering tasks.

### US-3: FreeCAD Part Design

> **As a** mechanical engineer,  
> **I want** to create parametric parts via CLI,  
> **So that** I can integrate CAD generation into my CI/CD pipeline.

### US-4: ML Model Training

> **As a** data scientist,  
> **I want** to train forecasting models from CSV data,  
> **So that** I can predict future trends without GUI interaction.

## 5. Acceptance Criteria

### AC-1: Project Structure
- [x] `pyproject.toml` with all dependencies defined
- [x] `README.md` with installation instructions
- [ ] All source files created in `src/` directory
- [ ] Test files in `tests/` directory
- [ ] Documentation in `docs/` folder

### AC-2: CLI Functionality
- [x] CLI accepts subcommands without errors
- [x] Help text displays correctly
- [ ] Each module command executes successfully
- [ ] Error messages are informative and actionable

### AC-3: Module Implementation
- [ ] Blender module validates installation
- [ ] FreeCAD module validates installation  
- [ ] ML module loads TensorFlow and Keras successfully
- [ ] All modules provide appropriate exit codes

### AC-4: Testing
- [ ] Test suite achieves ≥30% coverage
- [ ] No critical (CRITICAL) or high (HIGH) severity bugs
- [ ] All unit tests pass with `pytest`

### AC-5: Documentation
- [x] PRD complete and approved
- [ ] Architecture documentation written
- [ ] User stories documented
- [ ] Code comments explain complex logic

## 6. Out of Scope

The following items are intentionally excluded from the initial release:

1. **GUI Integration**: No graphical interface; CLI-only
2. **Real-time Collaboration**: Single-user application
3. **Cloud Deployment**: Local execution only (Docker support can be added later)
4. **Multi-threaded Training**: Sequential ML training for simplicity
5. **Blender Add-on Installation**: Uses standard Blender installation

## 7. Definitions and Acronyms

| Term | Definition |
|------|------------|
| BPY | Blender Python API |
| CLI | Command-Line Interface |
| CAD | Computer-Aided Design |
| ML | Machine Learning |
| MAE | Mean Absolute Error |
| RMSE | Root Mean Square Error |
| MAPE | Mean Absolute Percentage Error |
| HDF5 | Hierarchical Data Format version 5 |
| MLP | Multi-Layer Perceptron |
| LSTM | Long Short-Term Memory (recurrent neural network) |

## 8. Appendices

### Appendix A: Command Reference

```bash
# Blender commands
bmad-cli cad generate-blender <scene_name> [--config config.yaml]
bmad-cli cad export-blender --format {obj,fbx,gltf} <scene_name>

# FreeCAD commands  
bmad-cli cad generate-freecad <model_name> [--config config.yaml]
bmad-cli cad export-freecad --format {step,iges,stl} <model_name>

# ML commands
bmad-cli forecast train <dataset_path> [options]
bmad-cli forecast evaluate <model_path> --dataset <data_path>
bmad-cli forecast predict --model <model_path> --input <features>
```

### Appendix B: File Dependencies

| Source File | Depends On | Provides |
|-------------|------------|----------|
| `src/cli/main.py` | None | CLI entry point |
| `src/cli/commands/blender_cmd.py` | `bpy`, subprocess | Blender orchestration |
| `src/cli/commands/freecad_cmd.py` | FreeCAD Python API | CAD orchestration |
| `src/cli/commands/forecast_cmd.py` | Keras, NumPy | ML pipeline |
| `src/cad/blender/scene_builder.py` | bpy module | Scene construction |
| `src/cad/freecad/model_builder.py` | FreeCAD kernel | Part design |
| `src/ml/model.py` | TensorFlow/Keras | Model architecture |
| `src/ml/tuner.py` | Keras Tuner | Hyperparameter search |

### Appendix C: Risk Register

| ID | Risk | Probability | Impact | Mitigation |
|----|------|-------------|--------|------------|
| R1 | Blender subprocess fails on Windows | Medium | High | Provide fallback error messages and PATH validation |
| R2 | FreeCAD Python API changes | Medium | Medium | Use version-agnostic API calls; document breaking changes |
| R3 | TensorFlow GPU incompatibility | Low | Medium | Support CPU-only mode by default |
| R4 | Memory limits on large datasets | Medium | Medium | Implement memory-mapped arrays and chunked loading |

---

*Document Status: In Review*  
*Next Review Date: 2024-12-17*